Chapter kicker above every section headline: "01 — WHAT WE’RE ABOUT".

```jsx
<SectionNumber number={1} label="What we’re about" />
<SectionNumber label="Meet the mascot" color="var(--ratto-red)" />
```
