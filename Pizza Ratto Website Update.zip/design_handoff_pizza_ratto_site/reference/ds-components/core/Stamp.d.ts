import * as React from "react";
/** Flat round stamp: Futura caps label, Cooper centre line. */
export interface StampProps {
  /** Small caps line above, e.g. "Open" */
  top?: React.ReactNode;
  /** Cooper centre line, e.g. "Mon–Sat" or "R50" */
  main?: React.ReactNode;
  /** Small caps line below, e.g. "10—18" */
  sub?: React.ReactNode;
  tone?: "hot" | "pink" | "red" | "cream" | "brown";
  /** Diameter px. Default 120 */
  size?: number;
  /** Degrees. Default 8 */
  rotate?: number;
  style?: React.CSSProperties;
}
export declare function Stamp(props: StampProps): JSX.Element;
