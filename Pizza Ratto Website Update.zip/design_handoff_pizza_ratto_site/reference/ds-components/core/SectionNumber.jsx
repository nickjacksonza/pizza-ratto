import React from "react";
export function SectionNumber({ number, label, color = "inherit", rule = true, style }) {
  return <p style={{ margin: "0 0 1.4rem", display: "flex", alignItems: "center", gap: ".9rem", color, fontFamily: "var(--font-body)", fontSize: ".78rem", fontWeight: 600, lineHeight: 1.2, letterSpacing: ".16em", textTransform: "uppercase", ...style }}>
    {number != null && <span style={{ fontFamily: "var(--font-display)", fontSize: "1.1rem", letterSpacing: 0 }}>{String(number).padStart(2, "0")}</span>}
    {number != null && rule && <span aria-hidden="true" style={{ width: 28, height: 1.5, background: "currentColor" }} />}
    <span>{label}</span>
  </p>;
}
