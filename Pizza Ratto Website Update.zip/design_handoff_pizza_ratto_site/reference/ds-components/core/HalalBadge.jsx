import React from "react";
export function HalalBadge({ size = 200, label = "HALAL", color = "var(--ink-black)", background = "var(--white)", style }) {
  const k = size / 200;
  return <div role="img" aria-label={label} style={{ position: "relative", width: size, height: size, flex: "0 0 auto", ...style }}>
    <div style={{ position: "absolute", left: 10 * k, top: 10 * k, width: 180 * k, height: 180 * k, borderRadius: "50%", background, boxShadow: `inset 0 0 0 ${6 * k}px ${color}`, display: "grid", placeItems: "center" }}>
      <span style={{ fontFamily: "var(--font-body)", fontWeight: 900, fontSize: 28 * k, lineHeight: 1, color, letterSpacing: ".02em" }}>{label}</span>
    </div>
  </div>;
}
