import React from "react";
const base = { fontFamily: "var(--font-body)", fontWeight: 600, letterSpacing: ".14em", textTransform: "uppercase", fontSize: ".68rem", lineHeight: 1, padding: ".42rem .7rem", borderRadius: "var(--radius-pill)" };
const V = {
  note: { ...base, color: "var(--paper-cream)", background: "var(--ratto-red)" },
  price: { ...base, color: "var(--paper-cream)", background: "var(--ratto-brown)" },
  pink: { ...base, color: "var(--ratto-brown)", background: "var(--ratto-pink)" },
  hot: { ...base, color: "var(--ratto-brown)", background: "var(--hot-orange)" },
  outline: { ...base, color: "var(--ratto-brown)", background: "transparent", boxShadow: "inset 0 0 0 1.5px var(--ratto-brown)" },
  aside: { color: "var(--ratto-red)", fontFamily: "var(--font-display)", fontSize: "1.35rem", lineHeight: 1.05, rot: -4 },
};
export function Sticker({ variant = "note", rotate, children, style }) {
  const { rot = 0, ...v } = V[variant] || V.note;
  const r = rotate ?? rot;
  return <span style={{ display: "inline-block", width: "max-content", maxWidth: "100%", boxSizing: "border-box", ...v, transform: r ? `rotate(${r}deg)` : undefined, ...style }}>{children}</span>;
}
