import * as React from "react";
/** Figma "Badge/Halal": 180px ring with 6px stroke inside a 200px frame. */
export interface HalalBadgeProps {
  /** Frame size px. Default 200 (all internals scale) */
  size?: number;
  label?: string;
  color?: string;
  background?: string;
  style?: React.CSSProperties;
}
export declare function HalalBadge(props: HalalBadgeProps): JSX.Element;
