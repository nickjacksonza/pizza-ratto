Racing checker band — a thin divider that always runs edge to edge. One per page section boundary at most.

```jsx
<CheckerStrip />
<CheckerStrip variant="pink" size={20} />
```
