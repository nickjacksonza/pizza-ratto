import React from "react";
const P = { ink: ["var(--ratto-brown)","var(--paper-cream)"], hot: ["var(--ratto-red)","var(--paper-cream)"], pink: ["var(--ratto-red)","var(--ratto-pink)"], orange: ["var(--hot-orange)","var(--paper-cream)"], stencil: ["var(--ink-black)","var(--white)"] };
export function CheckerStrip({ variant = "ink", size = 28, rows = 1, rotate = 0, style }) {
  const [a, b] = P[variant] || P.ink;
  return <div aria-hidden="true" style={{ width: "100%", height: size * rows, background: `repeating-conic-gradient(${a} 0 25%, ${b} 0 50%) 0 / ${size}px ${size}px`, transform: rotate ? `rotate(${rotate}deg)` : undefined, ...style }} />;
}
