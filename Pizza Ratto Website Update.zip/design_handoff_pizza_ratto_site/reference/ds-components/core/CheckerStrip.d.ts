import * as React from "react";
/** Full-bleed racing checker band (Vespa / race-flag reference). */
export interface CheckerStripProps {
  /** ink = brown/cream (default); hot = red/cream; pink = red/pink; orange = orange/cream; stencil = black/white */
  variant?: "ink" | "hot" | "pink" | "orange" | "stencil";
  /** Square px. Default 28 */
  size?: number;
  rows?: number;
  rotate?: number;
  style?: React.CSSProperties;
}
export declare function CheckerStrip(props: CheckerStripProps): JSX.Element;
