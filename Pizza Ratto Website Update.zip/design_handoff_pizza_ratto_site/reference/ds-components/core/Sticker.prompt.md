Small label: pill chips for menu notes and price groups, a tilted Cooper aside for jokes.

```jsx
<Sticker variant="note">New special</Sticker>
<Sticker variant="price">R30</Sticker>
<Sticker variant="aside">No shortcuts. No sad crusts.</Sticker>
```
