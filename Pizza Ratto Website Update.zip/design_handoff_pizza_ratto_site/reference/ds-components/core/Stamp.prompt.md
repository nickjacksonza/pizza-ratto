Flat circular stamp for hours, prices and specials — overlaps a photo or headline edge, slightly rotated.

```jsx
<Stamp top="Open" main="Mon–Sat" sub="10 — 18" />
<Stamp tone="red" top="Special" main="R50" sub="Tuesdays" rotate={-10} />
```
