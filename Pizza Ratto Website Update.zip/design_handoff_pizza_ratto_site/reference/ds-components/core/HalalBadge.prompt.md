Round certification badge (Figma "Badge/Halal") for menus and print — meat toppings are halal.

```jsx
<HalalBadge size={96} />
<HalalBadge size={72} color="var(--ratto-brown)" background="var(--paper-cream)" />
```
