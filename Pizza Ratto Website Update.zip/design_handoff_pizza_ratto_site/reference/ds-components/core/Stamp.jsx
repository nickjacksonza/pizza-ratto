import React from "react";
const T = { hot: ["var(--hot-orange)","var(--ratto-brown)"], pink: ["var(--ratto-pink)","var(--ratto-brown)"], red: ["var(--ratto-red)","var(--paper-cream)"], cream: ["var(--paper-cream)","var(--ratto-brown)"], brown: ["var(--ratto-brown)","var(--paper-cream)"] };
export function Stamp({ top, main, sub, tone = "hot", size = 120, rotate = 8, style }) {
  const [bg, fg] = T[tone] || T.hot;
  return <div style={{ width: size, height: size, padding: size * .1, display: "grid", placeContent: "center", gap: size * .02, textAlign: "center", color: fg, background: bg, borderRadius: "50%", transform: `rotate(${rotate}deg)`, boxSizing: "border-box", flex: "0 0 auto", ...style }}>
    {top && <span style={{ fontFamily: "var(--font-body)", fontWeight: 600, fontSize: size * .075, letterSpacing: ".16em", textTransform: "uppercase" }}>{top}</span>}
    {main && <strong style={{ fontFamily: "var(--font-display)", fontWeight: 400, fontSize: size * .2, lineHeight: .95 }}>{main}</strong>}
    {sub && <span style={{ fontFamily: "var(--font-body)", fontWeight: 600, fontSize: size * .075, letterSpacing: ".12em", textTransform: "uppercase" }}>{sub}</span>}
  </div>;
}
