Inline service glyph (WhatsApp, Call, Uber Eats, Instagram) for order buttons and footer links.

```jsx
<BrandIcon name="whatsapp" />
<BrandIcon name="instagram" size={24} title="Instagram" />
```

- Inherits `currentColor`; sits beside visible text, never replaces it (except icon-only footer social with `title`).
