import * as React from "react";
/**
 * Flat pill button, Futura caps. Hover swaps colour (red → brown); press scales to .97.
 * `street` is the one underground variant: ink border + hard offset shadow.
 * @startingPoint section="Core" subtitle="Flat pill CTA" viewport="700x220"
 */
export interface ButtonProps {
  /** primary = red; hot = orange; dark = brown; cream = for dark fields; outline = 1.5px brown rule; street = bordered + hard shadow */
  variant?: "primary" | "hot" | "dark" | "cream" | "outline" | "street";
  size?: "md" | "sm";
  /** Leading service glyph */
  icon?: "call" | "instagram" | "ubereats" | "whatsapp";
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
  disabled?: boolean;
  block?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
