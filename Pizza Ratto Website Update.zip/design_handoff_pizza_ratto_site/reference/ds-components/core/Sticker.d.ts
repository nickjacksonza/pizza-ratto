import * as React from "react";
/** Small label: pill chips (note/price/pink/hot/outline) or a tilted Cooper aside. */
export interface StickerProps {
  /** note = red availability; price = brown price group; pink / hot / outline = trait chips; aside = Cooper red one-liner, tilted */
  variant?: "note" | "price" | "pink" | "hot" | "outline" | "aside";
  rotate?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Sticker(props: StickerProps): JSX.Element;
