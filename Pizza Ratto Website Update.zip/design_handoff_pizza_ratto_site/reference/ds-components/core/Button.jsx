import React from "react";
import { BrandIcon } from "./BrandIcon.jsx";
const V = {
  primary: ["var(--ratto-red)", "var(--paper-cream)", "var(--ratto-brown)", "var(--paper-cream)"],
  hot: ["var(--hot-orange)", "var(--ratto-brown)", "var(--ratto-brown)", "var(--paper-cream)"],
  dark: ["var(--ratto-brown)", "var(--paper-cream)", "var(--ratto-red)", "var(--paper-cream)"],
  cream: ["var(--paper-cream)", "var(--ratto-brown)", "var(--ratto-pink)", "var(--ratto-brown)"],
  outline: ["transparent", "var(--ratto-brown)", "var(--ratto-brown)", "var(--paper-cream)"],
  street: ["var(--ratto-red)", "var(--paper-cream)", "var(--hot-orange)", "var(--ratto-brown)"],
};
export function Button({ variant = "primary", size = "md", icon, href, onClick, disabled = false, block = false, children, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const [bg, fg, hbg, hfg] = V[variant] || V.primary;
  const live = hover && !disabled;
  const sm = size === "sm";
  const street = variant === "street";
  const outline = variant === "outline";
  const s = {
    minHeight: sm ? 40 : 52, padding: sm ? ".55rem 1.1rem" : ".85rem 1.6rem",
    display: block ? "flex" : "inline-flex", width: block ? "100%" : undefined, alignItems: "center", justifyContent: "center", gap: ".55rem",
    color: live ? hfg : fg, background: live ? hbg : bg,
    border: outline ? "1.5px solid var(--ratto-brown)" : street ? "3px solid var(--ratto-brown)" : "0",
    borderRadius: "var(--radius-pill)", boxShadow: street ? "6px 6px 0 var(--ratto-brown)" : "none",
    fontFamily: "var(--font-body)", fontSize: sm ? ".74rem" : ".86rem", fontWeight: 600, letterSpacing: ".1em", textTransform: "uppercase", lineHeight: 1,
    textDecoration: "none", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? .4 : 1,
    transform: press && !disabled ? "scale(.97)" : street && live ? "translate(-2px,-2px)" : "none",
    transition: "background .15s ease, color .15s ease, transform .15s ease", boxSizing: "border-box", ...style,
  };
  const Tag = href ? "a" : "button";
  return <Tag href={href} onClick={disabled ? undefined : onClick} disabled={Tag === "button" ? disabled : undefined} aria-disabled={disabled || undefined}
    onMouseEnter={() => setHover(true)} onMouseLeave={() => { setHover(false); setPress(false); }} onMouseDown={() => setPress(true)} onMouseUp={() => setPress(false)} style={s} {...rest}>
    {icon && <BrandIcon name={icon} />}{children}
  </Tag>;
}
