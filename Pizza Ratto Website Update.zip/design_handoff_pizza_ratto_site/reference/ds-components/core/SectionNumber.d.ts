import * as React from "react";
/** Chapter kicker: Cooper number, short rule, Futura caps label. */
export interface SectionNumberProps {
  /** Zero-padded to two digits; omit for label-only */
  number?: number | string;
  label: React.ReactNode;
  color?: string;
  /** Show the short rule between number and label. Default true */
  rule?: boolean;
  style?: React.CSSProperties;
}
export declare function SectionNumber(props: SectionNumberProps): JSX.Element;
