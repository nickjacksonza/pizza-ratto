import * as React from "react";
/** Service glyphs used on order actions (from the website's BrandIcon). */
export interface BrandIconProps {
  /** Glyph name */
  name?: "call" | "instagram" | "ubereats" | "whatsapp";
  /** CSS size (height); ubereats is 1.5× wider. Default 1.15em */
  size?: number | string;
  color?: string;
  /** Accessible label; omit to hide from assistive tech */
  title?: string;
  style?: React.CSSProperties;
}
export declare function BrandIcon(props: BrandIconProps): JSX.Element;
