Primary call-to-action: flat, borderless pill in Futura caps — use for every order and menu action.

```jsx
<Button icon="whatsapp" href="https://wa.me/27825250380">Order on WhatsApp</Button>
<Button variant="hot" icon="ubereats">Uber Eats</Button>
<Button variant="street">Zero permission</Button>
```

- Max one `street` button per view — it is the underground accent, not the default.
- On red/brown fields use `cream` or `hot`.
