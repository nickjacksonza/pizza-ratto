32px announcement strip above the header with hours/location separated by orange dots.

```jsx
<AnnouncementBar />
```
