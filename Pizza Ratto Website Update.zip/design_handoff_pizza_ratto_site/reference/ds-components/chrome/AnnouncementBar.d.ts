import * as React from "react";
/** Thin top bar, Futura caps, orange dot separators. */
export interface AnnouncementBarProps {
  items?: React.ReactNode[];
  tone?: "brown" | "red";
  style?: React.CSSProperties;
}
export declare function AnnouncementBar(props: AnnouncementBarProps): JSX.Element;
