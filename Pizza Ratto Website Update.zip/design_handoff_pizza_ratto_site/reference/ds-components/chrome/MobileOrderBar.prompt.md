Phone-only sticky ordering bar (≤520px): WhatsApp highlighted, Call, Uber Eats — an ordering surface, not navigation.

```jsx
<MobileOrderBar style={{ position: "fixed", left: 0, right: 0, bottom: 0 }} />
```
