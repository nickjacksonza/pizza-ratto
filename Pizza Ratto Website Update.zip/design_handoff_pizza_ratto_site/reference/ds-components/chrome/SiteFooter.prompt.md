Brown site footer: pink Avant Garde tagline, Where / When / Call columns with orange labels, Instagram circle.

```jsx
<SiteFooter />
```
