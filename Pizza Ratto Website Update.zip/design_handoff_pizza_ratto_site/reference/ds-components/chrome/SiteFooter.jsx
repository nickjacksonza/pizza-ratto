import React from "react";
import { BrandIcon } from "../core/BrandIcon.jsx";
import { Wordmark } from "../brand/Wordmark.jsx";
export function SiteFooter({ assetBase = "", tagline = "Italian soul. Street-corner attitude.", address = "20 Brickfield Road, Salt River, Cape Town", hours = "Monday–Saturday, 10:00–18:00", phone = "082 525 0380", year = new Date().getFullYear(), instagramUrl = "https://www.instagram.com/pizza_ratto/", style }) {
  const lbl = { margin: "0 0 .5rem", fontSize: ".68rem", fontWeight: 600, letterSpacing: ".16em", textTransform: "uppercase", color: "var(--hot-orange)" };
  const p = { margin: 0, fontSize: ".95rem", lineHeight: 1.5 };
  return <footer style={{ padding: "4rem clamp(1.25rem,5vw,5rem) 2.5rem", color: "var(--paper-cream)", background: "var(--ratto-brown)", fontFamily: "var(--font-body)", ...style }}>
    <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.4fr) repeat(3,minmax(0,1fr))", gap: "2rem", alignItems: "start" }}>
      <div><p style={{ margin: 0, fontFamily: "var(--font-headline)", fontWeight: 700, fontSize: "clamp(2rem,3.4vw,3rem)", letterSpacing: "-.035em", lineHeight: .95, color: "var(--ratto-pink)" }}>{tagline}</p></div>
      <div><p style={lbl}>Where</p><p style={p}>{address}</p></div>
      <div><p style={lbl}>When</p><p style={p}>{hours}</p></div>
      <div><p style={lbl}>Call / WhatsApp</p><p style={{ ...p, fontFamily: "var(--font-display)", fontSize: "1.4rem" }}>{phone}</p></div>
    </div>
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", marginTop: "3rem", paddingTop: "1.2rem", borderTop: "1.5px solid rgba(245,240,230,.35)" }}>
      <p style={{ margin: 0, fontSize: ".72rem", letterSpacing: ".08em" }}>© {year} Pizza Ratto · Built with fire, not focus groups.</p>
      <a href={instagramUrl} target="_blank" rel="noreferrer" aria-label="Pizza Ratto on Instagram @pizza_ratto" style={{ width: 44, height: 44, display: "grid", placeItems: "center", color: "var(--ratto-brown)", background: "var(--ratto-pink)", borderRadius: "50%" }}><BrandIcon name="instagram" size={22} /></a>
    </div>
  </footer>;
}
