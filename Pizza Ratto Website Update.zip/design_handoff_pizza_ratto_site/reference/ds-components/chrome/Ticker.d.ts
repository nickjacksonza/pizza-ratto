import * as React from "react";
/** Slow Cooper marquee band between chapters. */
export interface TickerProps {
  /** One run; repeated and doubled for a seamless loop */
  text?: string;
  /** Seconds per loop. Default 22 */
  duration?: number;
  tone?: "red" | "hot" | "brown" | "pink";
  animate?: boolean;
  style?: React.CSSProperties;
}
export declare function Ticker(props: TickerProps): JSX.Element;
