import React from "react";
export function AnnouncementBar({ items = ["Made fresh. Taken seriously by no one.", "Wood-fired in Salt River", "Mon–Sat 10:00–18:00"], tone = "brown", style }) {
  const bg = tone === "red" ? "var(--ratto-red)" : "var(--ratto-brown)";
  return <div role="note" style={{ overflow: "hidden", color: "var(--paper-cream)", background: bg, whiteSpace: "nowrap", textTransform: "uppercase", letterSpacing: ".16em", fontSize: ".68rem", fontWeight: 600, fontFamily: "var(--font-body)", textAlign: "center", padding: ".62rem 1rem", ...style }}>
    {items.map((t, i) => <React.Fragment key={i}>{i > 0 && <span aria-hidden="true" style={{ display: "inline-block", width: 6, height: 6, margin: "0 1rem", borderRadius: "50%", background: "var(--hot-orange)", verticalAlign: "middle" }} />}{t}</React.Fragment>)}
  </div>;
}
