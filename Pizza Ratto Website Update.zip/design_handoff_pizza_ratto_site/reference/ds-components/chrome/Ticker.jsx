import React from "react";
export function Ticker({ text = "Italian soul ● Street-corner attitude ● Pizza, done properly ● ", duration = 22, tone = "red", animate = true, style }) {
  const id = React.useMemo(() => "prtk" + Math.random().toString(36).slice(2, 7), []);
  const map = { red: ["var(--ratto-red)", "var(--paper-cream)"], hot: ["var(--hot-orange)", "var(--ratto-brown)"], brown: ["var(--ratto-brown)", "var(--ratto-pink)"], pink: ["var(--ratto-pink)", "var(--ratto-red)"] };
  const [bg, fg] = map[tone] || map.red;
  const run = text.repeat(4);
  return <div aria-hidden="true" style={{ overflow: "hidden", padding: ".7rem 0", color: fg, background: bg, whiteSpace: "nowrap", fontFamily: "var(--font-display)", fontSize: "1.6rem", lineHeight: 1.1, ...style }}>
    <style>{`@keyframes ${id}{to{transform:translateX(-50%)}}@media (prefers-reduced-motion:reduce){.${id}{animation:none!important}}`}</style>
    <div className={id} style={{ display: "flex", width: "max-content", animation: animate ? `${id} ${duration}s linear infinite` : "none" }}><span>{run}</span><span>{run}</span></div>
  </div>;
}
