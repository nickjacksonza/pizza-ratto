import * as React from "react";
/** Cream header: original wordmark, Futura caps nav (red on hover, red dot when active), red order pill. */
export interface SiteHeaderProps {
  assetBase?: string;
  links?: { label: string; href: string }[];
  active?: string;
  onNavigate?: (id: string) => void;
  ctaLabel?: string;
  ctaHref?: string;
  style?: React.CSSProperties;
}
export declare function SiteHeader(props: SiteHeaderProps): JSX.Element;
