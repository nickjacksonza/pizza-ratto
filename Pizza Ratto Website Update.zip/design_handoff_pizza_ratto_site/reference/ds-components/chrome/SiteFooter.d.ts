import * as React from "react";
/** Brown footer: Avant Garde tagline, Where/When/Call columns, Instagram circle. */
export interface SiteFooterProps {
  assetBase?: string;
  tagline?: string;
  address?: string;
  hours?: string;
  phone?: string;
  year?: number;
  instagramUrl?: string;
  style?: React.CSSProperties;
}
export declare function SiteFooter(props: SiteFooterProps): JSX.Element;
