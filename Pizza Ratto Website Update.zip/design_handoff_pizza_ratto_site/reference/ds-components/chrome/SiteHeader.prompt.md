Website header: original stacked wordmark, three Futura caps links, red WhatsApp "Order now" pill; 1.5px brown bottom rule.

```jsx
<SiteHeader assetBase="../../" active="Menu" onNavigate={setPage} />
```
