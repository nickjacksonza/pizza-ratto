Slow Cooper marquee band between chapters; stops under reduced motion.

```jsx
<Ticker />
<Ticker tone="hot" text="Follow the rat ● Caffè · Pizza · Chaos ● " />
```
