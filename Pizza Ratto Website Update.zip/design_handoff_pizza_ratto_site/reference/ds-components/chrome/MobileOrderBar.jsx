import React from "react";
import { BrandIcon } from "../core/BrandIcon.jsx";
export function MobileOrderBar({ whatsappUrl = "https://wa.me/27825250380", phone = "+27825250380", uberUrl = "https://www.ubereats.com/za/store/pizza-ratto/c2X95IU_SWaBTX_qeHpCng", style }) {
  const a = (bg, fg) => ({ minHeight: 64, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: ".3rem", color: fg, background: bg, textDecoration: "none", fontSize: ".66rem", fontWeight: 600, letterSpacing: ".14em", textTransform: "uppercase" });
  return <nav aria-label="Quick order actions" style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr 1fr", fontFamily: "var(--font-body)", ...style }}>
    <a href={whatsappUrl} style={a("var(--ratto-red)", "var(--paper-cream)")}><BrandIcon name="whatsapp" size={20} />WhatsApp</a>
    <a href={"tel:" + phone} style={a("var(--hot-orange)", "var(--ratto-brown)")}><BrandIcon name="call" size={20} />Call</a>
    <a href={uberUrl} style={a("var(--ratto-brown)", "var(--paper-cream)")}><BrandIcon name="ubereats" size={18} />Uber Eats</a>
  </nav>;
}
