import React from "react";
import { Button } from "../core/Button.jsx";
import { Wordmark } from "../brand/Wordmark.jsx";
export function SiteHeader({ assetBase = "", links = [{ label: "Menu", href: "#menu" }, { label: "About", href: "#story" }, { label: "Visit", href: "#visit" }], active, onNavigate, ctaLabel = "Order now", ctaHref = "https://wa.me/27825250380", style }) {
  const [hov, setHov] = React.useState(null);
  return <header style={{ minHeight: 72, padding: "0 clamp(1rem,4vw,4rem)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1.5rem", background: "var(--paper-cream)", borderBottom: "1.5px solid var(--ratto-brown)", color: "var(--ratto-brown)", fontFamily: "var(--font-body)", ...style }}>
    <a href="#top" aria-label="Pizza Ratto home" onClick={onNavigate ? (e) => { e.preventDefault(); onNavigate("top"); } : undefined} style={{ display: "grid", placeItems: "center" }}>
      <Wordmark assetBase={assetBase} width={60} alt="" />
    </a>
    <nav style={{ display: "flex", gap: "2.4rem", marginLeft: "auto", textTransform: "uppercase", fontSize: ".76rem", fontWeight: 600, letterSpacing: ".16em" }}>
      {links.map((l) => { const on = hov === l.label || active === l.label; return <a key={l.label} href={l.href} onClick={onNavigate ? (e) => { e.preventDefault(); onNavigate(l.href.replace("#", "")); } : undefined}
        onMouseEnter={() => setHov(l.label)} onMouseLeave={() => setHov(null)}
        style={{ minHeight: 44, display: "inline-flex", alignItems: "center", gap: ".5rem", color: on ? "var(--ratto-red)" : "inherit", textDecoration: "none" }}>
        <span aria-hidden="true" style={{ width: 7, height: 7, borderRadius: "50%", background: active === l.label ? "var(--ratto-red)" : "transparent" }} />{l.label}</a>; })}
    </nav>
    <Button size="sm" icon="whatsapp" href={ctaHref}>{ctaLabel}</Button>
  </header>;
}
