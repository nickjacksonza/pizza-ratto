import * as React from "react";
/** Fixed bottom ordering bar for phones: WhatsApp (primary) · Call · Uber Eats, 64px targets. */
export interface MobileOrderBarProps {
  whatsappUrl?: string;
  phone?: string;
  uberUrl?: string;
  style?: React.CSSProperties;
}
export declare function MobileOrderBar(props: MobileOrderBarProps): JSX.Element;
