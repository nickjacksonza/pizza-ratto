import React from "react";
const TONE = { orange: "var(--hot-orange)", cream: "var(--paper-cream)", pink: "var(--ratto-pink)", white: "var(--white)" };
export function MenuCategory({ name, kicker, tone = "orange", mark, groups = [], style }) {
  return <section style={{ padding: "clamp(1.6rem,3vw,2.6rem)", background: TONE[tone] || tone, color: "var(--ratto-brown)", fontFamily: "var(--font-body)", borderRadius: "var(--radius-card)", ...style }}>
    <header style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: "1rem", paddingBottom: "1rem", borderBottom: "1.5px solid var(--ratto-brown)" }}>
      <div>
        <h3 style={{ margin: 0, color: "var(--ratto-red)", fontFamily: "var(--font-headline)", fontWeight: 700, fontSize: "clamp(2.2rem,3.4vw,3.2rem)", lineHeight: .92, letterSpacing: "-.035em" }}>{name}</h3>
        {kicker && <p style={{ margin: ".55rem 0 0", fontSize: ".9rem", lineHeight: 1.35 }}>{kicker}</p>}
      </div>
      {mark && <span style={{ flex: "0 0 auto", width: 64, display: "grid", placeItems: "center" }}>{mark}</span>}
    </header>
    <div style={{ display: "grid", gap: "1.1rem", marginTop: "1.1rem" }}>
      {groups.map((g, gi) => <div key={gi} style={{ display: "grid", gridTemplateColumns: "64px minmax(0,1fr)", gap: ".9rem", alignItems: "start" }}>
        <span style={{ marginTop: ".55rem", fontFamily: "var(--font-display)", fontSize: "1.25rem", color: "var(--ratto-red)", lineHeight: 1 }}>{g.price}</span>
        <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
          {(g.items || []).map((it, ii) => <li key={ii} style={{ display: "flex", justifyContent: "space-between", gap: "1rem", padding: ".55rem 0", borderBottom: "1px solid rgba(66,18,18,.28)" }}>
            <div><b style={{ fontSize: ".95rem", fontWeight: 600, letterSpacing: ".06em", textTransform: "uppercase" }}>{it.name}</b>
              {it.description && <p style={{ margin: ".2rem 0 0", fontSize: ".85rem", lineHeight: 1.35 }}>{it.description}</p>}
              {it.note && <small style={{ display: "block", marginTop: ".25rem", color: "var(--ratto-red)", fontSize: ".78rem" }}>{it.note}</small>}</div>
            {it.price != null && <strong style={{ color: "var(--ratto-red)", fontWeight: 600, whiteSpace: "nowrap" }}>{typeof it.price === "number" ? "R" + it.price : it.price}</strong>}
          </li>)}
        </ul>
      </div>)}
    </div>
  </section>;
}
