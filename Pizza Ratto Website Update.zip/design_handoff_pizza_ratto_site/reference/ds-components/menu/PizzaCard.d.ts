import * as React from "react";
/**
 * Pizza menu item: round photo (pizza is a circle), Cooper name + price over a 1.5px rule, Futura ingredients.
 * @startingPoint section="Menu" subtitle="Pizza card with round photo" viewport="700x420"
 */
export interface PizzaCardProps {
  name: string;
  /** Number renders as "R{n}" */
  price: number | string;
  description?: string;
  /** Red pill, e.g. "New special" */
  note?: string;
  /** Orange "House favourite" pill */
  featured?: boolean;
  /** Photo URL; omit for red placeholder disc */
  image?: string;
  alt?: string;
  /** stack (grid card, default) or row (compact list with 112px disc) */
  layout?: "stack" | "row";
  style?: React.CSSProperties;
}
export declare function PizzaCard(props: PizzaCardProps): JSX.Element;
