Pizza menu item: round photo, Cooper name and rand price over a thin rule, Futura ingredients. Disc rotates slightly on hover.

```jsx
<PizzaCard name="Sprint" price={120} description="Salami, caramelised onions and hot honey" image="assets/photos/pizza-sprint.webp" featured />
<PizzaCard layout="row" name="Sole" price={110} description="White base, yellow peppers, cherry tomatoes, mint" note="New special" />
```
