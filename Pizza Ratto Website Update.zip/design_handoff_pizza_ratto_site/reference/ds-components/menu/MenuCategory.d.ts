import * as React from "react";
export interface MenuCategoryItem { name: string; description?: string; note?: string; price?: number | string; }
export interface MenuCategoryGroup { /** Price label in the left column, e.g. "R30" */ price: string; items: MenuCategoryItem[]; }
/** Rounded flat panel listing drinks/desserts grouped by price. */
export interface MenuCategoryProps {
  name: string;
  kicker?: string;
  tone?: "orange" | "cream" | "pink" | "white";
  /** Small brand mark (e.g. <img src="assets/brand/red-cup.svg">) */
  mark?: React.ReactNode;
  groups?: MenuCategoryGroup[];
  style?: React.CSSProperties;
}
export declare function MenuCategory(props: MenuCategoryProps): JSX.Element;
