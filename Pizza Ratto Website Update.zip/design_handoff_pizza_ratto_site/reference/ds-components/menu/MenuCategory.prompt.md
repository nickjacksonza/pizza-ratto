Price-grouped menu panel for Caffè, Bevande and Dolci — flat colour, rounded 18px, price in a Cooper left column.

```jsx
<MenuCategory name="Caffè" kicker="For before, after, or instead of sensible decisions." mark={<img src="assets/brand/red-cup.svg" width="52" />}
  groups={[{ price: "R30", items: [{ name: "Americano" }, { name: "Cappuccino" }, { name: "Flat White" }] }]} />
```
