import React from "react";
export function PizzaCard({ name, price, description, note, featured = false, image, alt = "", layout = "stack", style }) {
  const [hover, setHover] = React.useState(false);
  const priceText = typeof price === "number" ? "R" + price : price;
  const row = layout === "row";
  return <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ minWidth: 0, display: "grid", gridTemplateColumns: row ? "112px minmax(0,1fr)" : "1fr", gap: row ? "1.2rem" : "1.1rem", alignItems: row ? "center" : "start", color: "var(--ratto-brown)", fontFamily: "var(--font-body)", ...style }}>
    <div style={{ width: "100%", aspectRatio: "1", borderRadius: "50%", overflow: "hidden", background: image ? "var(--ratto-pink)" : "var(--ratto-red)", display: "grid", placeItems: "center", transform: hover ? "rotate(-6deg)" : "none", transition: "transform .45s cubic-bezier(.2,.7,.2,1)" }}>
      {image ? <img src={image} alt={alt} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        : <span style={{ color: "var(--paper-cream)", fontFamily: "var(--font-display)", fontSize: "1.1rem", textAlign: "center", lineHeight: 1.05 }}>photo<br />coming hot</span>}
    </div>
    <div>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: ".8rem", paddingBottom: ".5rem", borderBottom: "1.5px solid var(--ratto-brown)" }}>
        <b style={{ fontFamily: "var(--font-display)", fontSize: row ? "1.6rem" : "clamp(1.6rem,2.4vw,2.2rem)", fontWeight: 400, lineHeight: 1 }}>{name}</b>
        <strong style={{ color: "var(--ratto-red)", fontFamily: "var(--font-display)", fontWeight: 400, fontSize: row ? "1.3rem" : "1.5rem", whiteSpace: "nowrap" }}>{priceText}</strong>
      </div>
      {description && <p style={{ margin: ".55rem 0 0", fontSize: ".98rem", lineHeight: 1.4 }}>{description}</p>}
      {(note || featured) && <div style={{ display: "flex", flexWrap: "wrap", gap: ".4rem", marginTop: ".7rem" }}>
        {note && <small style={{ padding: ".38rem .65rem", color: "var(--paper-cream)", background: "var(--ratto-red)", borderRadius: 999, fontSize: ".64rem", fontWeight: 600, letterSpacing: ".12em", textTransform: "uppercase", lineHeight: 1 }}>{note}</small>}
        {featured && <small style={{ padding: ".38rem .65rem", color: "var(--ratto-brown)", background: "var(--hot-orange)", borderRadius: 999, fontSize: ".64rem", fontWeight: 600, letterSpacing: ".12em", textTransform: "uppercase", lineHeight: 1 }}>House favourite</small>}
      </div>}
    </div>
  </div>;
}
