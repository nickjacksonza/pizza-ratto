Photo cropped to a clean geometric mask — circles for pizzas, arches for rooms and people.

```jsx
<PhotoCard shape="circle" src="assets/photos/pizza-sprint.webp" width={260} />
<PhotoCard shape="arch" src="assets/photos/interior.webp" caption="Salt River, CPT" />
```
