import React from "react";
const T = { red: ["var(--ratto-red)","var(--paper-cream)","var(--ratto-pink)"], brown: ["var(--ratto-brown)","var(--paper-cream)","var(--hot-orange)"], pink: ["var(--ratto-pink)","var(--ratto-brown)","var(--ratto-red)"], orange: ["var(--hot-orange)","var(--ratto-brown)","var(--paper-cream)"] };
export function RulesCard({ title = "House rules", items = [], numbered = true, tone = "red", rotate = 0, style }) {
  const [bg, fg, ac] = T[tone] || T.red;
  return <aside style={{ padding: "1.8rem 1.8rem 1.4rem", color: fg, background: bg, borderRadius: "var(--radius-card)", transform: rotate ? `rotate(${rotate}deg)` : undefined, fontFamily: "var(--font-body)", ...style }}>
    <b style={{ display: "block", marginBottom: ".9rem", color: ac, fontFamily: "var(--font-display)", fontWeight: 400, fontSize: "1.6rem", lineHeight: 1 }}>{title}</b>
    {items.map((it, i) => <span key={i} style={{ display: "flex", gap: ".9rem", alignItems: "baseline", padding: ".7rem 0", borderTop: "1.5px solid currentColor", fontWeight: 500, fontSize: "1rem" }}>
      {numbered && <span style={{ fontSize: ".72rem", fontWeight: 600, letterSpacing: ".14em", opacity: .8 }}>{String(i + 1).padStart(2, "0")}</span>}{it}</span>)}
  </aside>;
}
