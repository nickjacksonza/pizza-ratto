import * as React from "react";
/** Flat geometric shape for vintage-Italian-ad compositions and visual metaphors. */
export interface PopShapeProps {
  /** circle, ring, half, quarter, arch, leaf, bite (circle with bite marks), fruit (apple-like silhouette with stem), bitten (fruit with a bite), slice, pizza (circle + pepperoni dots), sun (sunburst), wheel */
  shape?: "circle" | "ring" | "half" | "quarter" | "arch" | "leaf" | "bite" | "fruit" | "bitten" | "slice" | "pizza" | "sun" | "wheel";
  /** Fill colour token. Default ratto red */
  color?: string;
  /** Secondary fill (bite cut-outs, pizza base). Should match the background. Default paper cream */
  accent?: string;
  size?: number;
  rotate?: number;
  style?: React.CSSProperties;
}
export declare function PopShape(props: PopShapeProps): JSX.Element;
