import * as React from "react";
/** Flat coloured card with a Cooper title and ruled list. */
export interface RulesCardProps {
  title?: React.ReactNode;
  items?: React.ReactNode[];
  numbered?: boolean;
  tone?: "red" | "brown" | "pink" | "orange";
  rotate?: number;
  style?: React.CSSProperties;
}
export declare function RulesCard(props: RulesCardProps): JSX.Element;
