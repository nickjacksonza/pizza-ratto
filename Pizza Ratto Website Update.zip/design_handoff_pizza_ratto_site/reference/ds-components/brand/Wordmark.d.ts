import * as React from "react";
/** The exact original Pizza Ratto artwork. Never redraw, retype or recolour it. */
export interface WordmarkProps {
  /** stacked = PIZZA/RATTO svg; banner = wide svg; hero = wordmark + Remi on peach; art = logo artwork png; stencil = original Remi stencil (b/w) */
  variant?: "stacked" | "banner" | "hero" | "art" | "stencil";
  /** Relative path from the page to the design-system root, e.g. "../../" */
  assetBase?: string;
  width?: number;
  rotate?: number;
  alt?: string;
  style?: React.CSSProperties;
}
export declare function Wordmark(props: WordmarkProps): JSX.Element;
