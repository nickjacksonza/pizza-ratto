import React from "react";
export function PopShape({ shape = "circle", color = "var(--ratto-red)", accent = "var(--paper-cream)", size = 160, rotate = 0, style }) {
  const st = { width: size, height: size, display: "block", flex: "0 0 auto", transform: rotate ? `rotate(${rotate}deg)` : undefined, ...style };
  const sh = {
    circle: <circle cx="50" cy="50" r="50" fill={color} />,
    ring: <circle cx="50" cy="50" r="40" fill="none" stroke={color} strokeWidth="20" />,
    half: <path d="M0 50a50 50 0 0 1 100 0Z" fill={color} />,
    quarter: <path d="M0 0h100A100 100 0 0 1 0 100Z" fill={color} />,
    arch: <path d="M0 100V50a50 50 0 0 1 100 0v50Z" fill={color} />,
    leaf: <path d="M2 50C20 12 80 12 98 50 80 88 20 88 2 50Z" fill={color} />,
    bite: <><circle cx="50" cy="50" r="50" fill={color} /><circle cx="104" cy="34" r="20" fill={accent} /><circle cx="100" cy="64" r="16" fill={accent} /></>,
    fruit: <><path d="M50 22C38 8 6 10 4 44c-2 32 22 56 46 56s48-24 46-56C94 10 62 8 50 22Z" fill={color} /><path d="M50 22 52 2" stroke={accent === "var(--paper-cream)" ? "var(--ratto-brown)" : accent} strokeWidth="3" strokeLinecap="round" /></>,
    bitten: <><path d="M50 22C38 8 6 10 4 44c-2 32 22 56 46 56s48-24 46-56C94 10 62 8 50 22Z" fill={color} /><circle cx="100" cy="46" r="18" fill={accent} /><circle cx="94" cy="74" r="14" fill={accent} /></>,
    slice: <path d="M50 4 96 96H4Z" fill={color} />,
    pizza: <><circle cx="50" cy="50" r="50" fill={color} /><circle cx="50" cy="50" r="38" fill={accent} /><circle cx="36" cy="38" r="8" fill={color} /><circle cx="62" cy="34" r="6" fill={color} /><circle cx="58" cy="62" r="9" fill={color} /><circle cx="34" cy="64" r="5" fill={color} /></>,
    sun: <>{Array.from({ length: 16 }).map((_, i) => <path key={i} d="M50 50 47 0h6Z" fill={color} transform={`rotate(${i * 22.5} 50 50)`} />)}<circle cx="50" cy="50" r="22" fill={color} /></>,
    wheel: <><circle cx="50" cy="50" r="44" fill="none" stroke={color} strokeWidth="12" /><circle cx="50" cy="50" r="12" fill={color} /></>,
  }[shape];
  return <svg viewBox="0 0 100 100" style={st} aria-hidden="true" overflow="visible">{sh}</svg>;
}
