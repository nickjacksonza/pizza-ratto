Flat geometric shape (circle, half, leaf, bite, slice, sunburst…) for asymmetric poster compositions and visual puns.

```jsx
<PopShape shape="bite" size={280} />  {/* a pizza with a rat-sized bite */}
<PopShape shape="leaf" color="var(--basil-green)" size={90} rotate={-20} />
<PopShape shape="sun" color="var(--hot-orange)" size={220} />
```

- Flat fills only: no outlines, gradients or shadows. Pair one big shape with one small.
- `bite` / `pizza` need `accent` = background colour.
