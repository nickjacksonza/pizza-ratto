Places the exact original Pizza Ratto logo/Remi artwork from assets/ — never retype the logo.

```jsx
<Wordmark assetBase="../../" width={64} />
<Wordmark variant="stencil" assetBase="../../" width={420} />
```
