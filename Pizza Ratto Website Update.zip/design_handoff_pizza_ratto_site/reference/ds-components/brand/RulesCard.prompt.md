Flat colour card with Cooper title and ruled list — house rules, facts, opening details.

```jsx
<RulesCard items={["Hand-stretched","Wood-fired","Proper ingredients","Zero fuss"]} />
<RulesCard tone="brown" title="Find us" items={["20 Brickfield Rd","Mon–Sat 10–18"]} numbered={false} />
```
