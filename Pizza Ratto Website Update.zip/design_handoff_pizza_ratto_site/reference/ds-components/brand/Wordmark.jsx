import React from "react";
const SRC = { stacked: "assets/brand/pizza-ratto-wordmark.svg", banner: "assets/brand/wordmark-banner.svg", hero: "assets/logo/hero-logo-mascot.png", art: "assets/logo/pizza-ratto-logo-art.png", stencil: "assets/mascot/remi-vespa-stencil-original.png" };
export function Wordmark({ variant = "stacked", assetBase = "", width = 120, rotate = 0, alt = "Pizza Ratto", style }) {
  return <img src={assetBase + (SRC[variant] || SRC.stacked)} alt={alt} style={{ width, height: "auto", display: "block", transform: rotate ? `rotate(${rotate}deg)` : undefined, ...style }} />;
}
