import React from "react";
const R = { rect: 0, rounded: "var(--radius-card)", circle: "50%", arch: "999px 999px 0 0", pill: "999px" };
export function PhotoCard({ src, alt = "", shape = "rect", aspect = "4 / 5", rotate = 0, background = "var(--ratto-pink)", shadow = null, caption, width = "100%", style }) {
  const round = shape === "circle";
  return <figure style={{ margin: 0, width, transform: rotate ? `rotate(${rotate}deg)` : undefined, ...style }}>
    <div style={{ position: "relative", aspectRatio: round ? "1" : aspect, overflow: "hidden", background, borderRadius: R[shape] ?? 0, boxShadow: shadow ? `6px 6px 0 ${shadow}` : "none" }}>
      {src && <img src={src} alt={alt} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />}
    </div>
    {caption && <figcaption style={{ marginTop: ".7rem", fontFamily: "var(--font-body)", fontSize: ".72rem", fontWeight: 600, letterSpacing: ".14em", textTransform: "uppercase", color: "inherit" }}>{caption}</figcaption>}
  </figure>;
}
