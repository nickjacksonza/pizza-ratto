import * as React from "react";
/** Photo cropped to a flat geometric mask (rect, rounded, circle, arch, pill). */
export interface PhotoCardProps {
  src?: string;
  alt?: string;
  shape?: "rect" | "rounded" | "circle" | "arch" | "pill";
  /** CSS aspect-ratio (ignored for circle). Default "4 / 5" */
  aspect?: string;
  rotate?: number;
  /** Fill behind the image while loading */
  background?: string;
  /** Optional hard offset shadow colour (underground accent). Default none */
  shadow?: string | null;
  /** Futura caps caption */
  caption?: React.ReactNode;
  width?: number | string;
  style?: React.CSSProperties;
}
export declare function PhotoCard(props: PhotoCardProps): JSX.Element;
