const prClamp = (v) => Math.max(0, Math.min(1, v));
const prMotionOK = (on) => on && !matchMedia("(prefers-reduced-motion: reduce)").matches;
let prFontP;
const prFont = () => prFontP || (prFontP = fetch(window.prAsset("assets/fonts/satisfy.json")).then(r => r.json()));

/* Handwritten word drawn stroke-by-stroke from the original site's Satisfy pen data. */
function Handwriting({ text, color, width = 6, motion, start = .95, span = .5, className, style }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    let off = false, unbind = () => {};
    prFont().then(font => {
      if (off || !ref.current) return;
      const svg = ref.current, NS = "http://www.w3.org/2000/svg";
      svg.replaceChildren(); const g = document.createElementNS(NS, "g"); svg.appendChild(g);
      let x = 0; const paths = [];
      for (const ch of text) {
        if (ch === " ") { x += font.p.space; continue; }
        const gl = font.c[ch.charCodeAt(0)]; if (!gl) continue;
        const cg = document.createElementNS(NS, "g"); g.appendChild(cg);
        gl.paths.forEach(p => { const el = document.createElementNS(NS, "path"); el.setAttribute("d", `M${p.mx} ${-p.my}` + p.d.replace(/^m\s*0,0/i, "")); cg.appendChild(el); paths.push(el); });
        const bb = cg.getBBox(); cg.setAttribute("transform", `translate(${x - bb.x} 0)`); x += bb.width + .3;
      }
      const bb = g.getBBox(), pad = 3;
      svg.setAttribute("viewBox", `${bb.x - pad} ${bb.y - pad} ${bb.width + pad * 2} ${bb.height + pad * 2}`);
      const L = paths.map(p => { p.setAttribute("fill", "none"); p.setAttribute("stroke", color); p.setAttribute("stroke-width", width); p.setAttribute("stroke-linecap", "round"); p.setAttribute("stroke-linejoin", "round"); return p.getTotalLength(); });
      const total = L.reduce((a, b) => a + b, 0);
      paths.forEach((p, i) => { p.style.strokeDasharray = `${L[i]} ${L[i] + 2}`; });
      const draw = (q) => { let d = q * total; paths.forEach((p, i) => { const s = Math.max(0, Math.min(L[i], d)); d -= L[i]; p.style.strokeDashoffset = L[i] - s; }); };
      if (!prMotionOK(motion)) { draw(1); return; }
      let raf = 0;
      const upd = () => { raf = 0; const r = svg.getBoundingClientRect(); draw(prClamp((innerHeight * start - r.top) / (innerHeight * span))); };
      const on = () => { if (!raf) raf = requestAnimationFrame(upd); };
      upd(); addEventListener("scroll", on, { passive: true }); addEventListener("resize", on);
      unbind = () => { removeEventListener("scroll", on); removeEventListener("resize", on); cancelAnimationFrame(raf); };
    });
    return () => { off = true; unbind(); };
  }, [text, color, width, motion]);
  return <svg ref={ref} className={className} style={style} aria-hidden="true" focusable="false"></svg>;
}

/* Scroll-locked chapters only on large desktop with motion allowed. */
function useLockable(motion) {
  const q = "(min-width: 1001px) and (min-height: 720px)";
  const [m, setM] = React.useState(() => matchMedia(q).matches);
  React.useEffect(() => { const mq = matchMedia(q); const f = () => setM(mq.matches); mq.addEventListener("change", f); return () => mq.removeEventListener("change", f); }, []);
  return m && prMotionOK(motion);
}

/* Remi breaks into pixel layers that drift away, left to right, while his chapter is locked. */
function useRemiDissolve(enabled, secRef, mediaRef, poofRef) {
  React.useEffect(() => {
    const sec = secRef.current, media = mediaRef.current, poof = poofRef.current;
    if (!enabled || !sec || !media) return;
    let off = false, frags = [], raf = 0;
    const upd = () => {
      raf = 0;
      const r = sec.getBoundingClientRect(), stage = sec.firstElementChild.offsetHeight;
      const top = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--chrome-h")) || 0;
      const p = prClamp((top - r.top) / Math.max(1, r.height - stage));
      const q = prClamp((p - .1) / .6);
      frags.forEach(cv => { const [dx, dy, rot, d] = cv._v; const l = prClamp((q - d * .55) / .45); cv.style.transform = l ? `translate(${dx * l}px,${dy * l}px) rotate(${rot * l}deg)` : ""; cv.style.opacity = 1 - l; });
      const k = prClamp((p - .55) / .2);
      poof.style.opacity = k; poof.style.transform = `translate(-50%,-50%) rotate(-4deg) scale(${.86 + .14 * k})`;
    };
    const on = () => { if (!raf) raf = requestAnimationFrame(upd); };
    const img = new Image(); img.decoding = "async";
    img.onload = () => {
      if (off) return;
      const W = 460, H = Math.round(W * img.naturalHeight / img.naturalWidth);
      const c = document.createElement("canvas"); c.width = W; c.height = H;
      const ctx = c.getContext("2d"); ctx.drawImage(img, 0, 0, W, H);
      let src; try { src = ctx.getImageData(0, 0, W, H).data; } catch (e) { return; }
      const N = 36, layers = Array.from({ length: N }, () => new ImageData(W, H));
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const k = (y * W + x) * 4; if (src[k + 3] < 8) continue;
        const i = Math.min(N - 1, Math.floor(N * (Math.random() + 2 * x / W) / 3)), d = layers[i].data;
        d[k] = src[k]; d[k + 1] = src[k + 1]; d[k + 2] = src[k + 2]; d[k + 3] = src[k + 3];
      }
      frags = layers.map((L, i) => {
        const cv = document.createElement("canvas"); cv.width = W; cv.height = H; cv.className = "pr-frag"; cv.setAttribute("aria-hidden", "true");
        cv.getContext("2d").putImageData(L, 0, 0);
        const a = (Math.random() * 2 - 1) * Math.PI;
        cv._v = [Math.cos(a) * 110, Math.sin(a) * 110 - 40, (Math.random() * 2 - 1) * 30, i / N];
        media.appendChild(cv); return cv;
      });
      media.classList.add("is-split"); on();
    };
    img.src = media.querySelector("img").currentSrc || media.querySelector("img").src;
    addEventListener("scroll", on, { passive: true }); addEventListener("resize", on); on();
    return () => { off = true; removeEventListener("scroll", on); removeEventListener("resize", on); cancelAnimationFrame(raf); frags.forEach(f => f.remove()); media.classList.remove("is-split"); poof.style.opacity = ""; poof.style.transform = ""; };
  }, [enabled]);
}

function SpinStamp({ motion, className = "", style }) {
  return <div className={"pr-spin-stamp " + className} style={style} role="img" aria-label="Open Monday to Saturday, 10:00 to 18:00">
    <svg viewBox="0 0 200 200" className={"pr-spin-ring" + (motion ? " on" : "")} aria-hidden="true"><defs><path id="prRing" d="M100,100 m-76,0 a76,76 0 1,1 152,0 a76,76 0 1,1 -152,0"></path></defs><text><textPath href="#prRing" textLength="474" lengthAdjust="spacing">MON–SAT ● 10:00–18:00 ● COLLECT · UBER EATS ● </textPath></text></svg>
    <div className="pr-spin-core" aria-hidden="true"><span>Open</span><b>10–18</b></div>
  </div>;
}

/* Muted loop that only plays while on screen; poster-only when motion is off. */
function TapeVideo({ tape, n, motion }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const v = ref.current; if (!v) return;
    if (!prMotionOK(motion)) { v.pause(); return; }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { v.play().catch(() => {}); } else v.pause(); }, { threshold: .4 });
    io.observe(v); return () => { io.disconnect(); v.pause(); };
  }, [motion]);
  return <figure className="pr-tape2">
    <video ref={ref} muted loop playsInline preload="none" disablePictureInPicture poster={window.prAsset("assets/photos/" + tape.img + ".webp")} width="720" height="1280" aria-hidden="true"><source src={window.prAsset("assets/videos/" + tape.vid + ".mp4")} type="video/mp4" /></video>
    <figcaption><b>{String(n).padStart(2, "0")}</b>{tape.label}</figcaption>
  </figure>;
}

Object.assign(window, { Handwriting, useLockable, useRemiDissolve, SpinStamp, TapeVideo, prMotionOK });
