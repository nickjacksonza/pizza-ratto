window.PR_SITE = {
  business: { name: "Pizza Ratto", tagline: "Italian soul. Street-corner attitude.", phone: "082 525 0380", phoneIntl: "+27825250380", location: "20 Brickfield Road, Salt River, Cape Town", hours: "Monday–Saturday, 10:00–18:00", deliveryNote: "Collection only", instagram: "https://www.instagram.com/pizza_ratto/", handle: "@pizza_ratto", uber: "https://www.ubereats.com/za/store/pizza-ratto/c2X95IU_SWaBTX_qeHpCng", whatsapp: "https://wa.me/27825250380?text=Hi%20Pizza%20Ratto%2C%20I%E2%80%99d%20like%20to%20place%20an%20order." },
  pizzas: [
    { name: "Bianca & Dip", description: "EVOO, rosemary, sea salt and fresh dip", price: 40, featured: true, img: "pizza-bianca", alt: "Rosemary flatbread with bowls of fresh dip and olive oil" },
    { name: "Primavera", description: "Tomatoes, mozzarella and basil", price: 80, img: "pizza-primavera", alt: "Tomato and mozzarella pizza finished with fresh basil" },
    { name: "Veloce", description: "Butternut, feta, onions and sunflower seeds", price: 100, img: "pizza-veloce", alt: "Pizza with roasted butternut, feta, onions and sunflower seeds" },
    { name: "Sprint", description: "Salami, caramelised onions and hot honey", price: 120, img: "pizza-sprint", alt: "Pizza with salami, caramelised onions, mozzarella and hot honey" },
    { name: "Arcobaleno", description: "Salami, feta, mushrooms and rocket", price: 140, img: "pizza-arcobaleno", alt: "Pizza with salami, mushrooms, feta and fresh rocket" },
    { name: "Bianca Pollo", description: "White base, smoked chicken, mushrooms and chives", price: 135, note: "New special", img: "pizza-bianca-pollo", alt: "White-base pizza with smoked chicken, mushrooms and chives" },
    { name: "Sole", description: "White base, yellow peppers, cherry tomatoes and mint", price: 110, note: "New special", img: "pizza-sole", alt: "White-base pizza with yellow peppers, cherry tomatoes and mint" },
    { name: "Rally", description: "BBQ glaze, smoked chicken, mushrooms and avocado", price: 150, featured: true, img: "pizza-rally", alt: "Pizza with smoked chicken, mushrooms and avocado" },
    { name: "Bosco", description: "Tomatoes, mozzarella, mushrooms, garlic, rosemary and rocket", price: 125, note: "Concept special", img: "pizza-bosco", alt: "Wood-fired pizza with mushrooms, garlic, rosemary and rocket" },
    { name: "Bandito", description: "Spicy salami, red onion, roasted peppers, chilli and hot honey", price: 145, note: "Concept special", img: "pizza-bandito", alt: "Wood-fired pizza with spicy salami, red onion, roasted peppers and chilli" },
    { name: "Verde", description: "Pesto, mozzarella, courgette, artichokes, feta and rocket", price: 130, note: "Concept special", img: "pizza-verde", alt: "Pesto pizza with courgette, artichokes, feta and rocket" },
    { name: "Tramonto", description: "Roasted peppers, onions, feta, cherry tomatoes and basil", price: 125, note: "Concept special", img: "pizza-tramonto", alt: "Wood-fired pizza with roasted peppers, onions, feta, cherry tomatoes and basil" }
  ],
  sides: [
    { name: "Caffè", tone: "orange", mark: "red-cup", kicker: "For before, after, or instead of sensible decisions.", groups: [{ price: "R15/20", items: [{ name: "Espresso", description: "Single · Double" }] }, { price: "R10", items: [{ name: "Decaf" }] }, { price: "R30", items: [{ name: "Americano" }, { name: "Cappuccino" }, { name: "Flat White" }] }, { price: "R35", items: [{ name: "Latte" }, { name: "Cortado" }] }, { price: "R40", items: [{ name: "Mocha" }, { name: "Iced Coffee" }] }] },
    { name: "Bevande", tone: "cream", kicker: "Beyond coffee. Still worth a stop.", groups: [{ price: "R15", items: [{ name: "Tea" }] }, { price: "R35", items: [{ name: "Hot Chocolate" }, { name: "Chai" }] }] },
    { name: "Dolci", tone: "pink", mark: "red-ice-cream", kicker: "Something sweet. No speech required.", groups: [{ price: "R40", items: [{ name: "Crema Dulce" }] }, { price: "R45", items: [{ name: "Gelato", description: "Nut Biscoff · Vanilla hot honey · Berries" }] }, { price: "R65", items: [{ name: "Limoncello" }] }] }
  ],
  tapes: [
    { img: "video-stills/oven-flames", label: "The fire stays ready" },
    { img: "video-stills/pizza-pass", label: "From oven to pass" },
    { img: "video-stills/espresso-pull", label: "Espresso pulling" }
  ]
};
