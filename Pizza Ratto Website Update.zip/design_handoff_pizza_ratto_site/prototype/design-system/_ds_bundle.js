/* @ds-bundle: {"format":4,"namespace":"PizzaRattoDesignSystem_c589b8","components":[{"name":"PhotoCard","sourcePath":"components/brand/PhotoCard.jsx"},{"name":"PopShape","sourcePath":"components/brand/PopShape.jsx"},{"name":"RulesCard","sourcePath":"components/brand/RulesCard.jsx"},{"name":"Wordmark","sourcePath":"components/brand/Wordmark.jsx"},{"name":"AnnouncementBar","sourcePath":"components/chrome/AnnouncementBar.jsx"},{"name":"MobileOrderBar","sourcePath":"components/chrome/MobileOrderBar.jsx"},{"name":"SiteFooter","sourcePath":"components/chrome/SiteFooter.jsx"},{"name":"SiteHeader","sourcePath":"components/chrome/SiteHeader.jsx"},{"name":"Ticker","sourcePath":"components/chrome/Ticker.jsx"},{"name":"BrandIcon","sourcePath":"components/core/BrandIcon.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"CheckerStrip","sourcePath":"components/core/CheckerStrip.jsx"},{"name":"HalalBadge","sourcePath":"components/core/HalalBadge.jsx"},{"name":"SectionNumber","sourcePath":"components/core/SectionNumber.jsx"},{"name":"Stamp","sourcePath":"components/core/Stamp.jsx"},{"name":"Sticker","sourcePath":"components/core/Sticker.jsx"},{"name":"MenuCategory","sourcePath":"components/menu/MenuCategory.jsx"},{"name":"PizzaCard","sourcePath":"components/menu/PizzaCard.jsx"}],"sourceHashes":{"components/brand/PhotoCard.jsx":"67c4532e4826","components/brand/PopShape.jsx":"03e24f25677d","components/brand/RulesCard.jsx":"b269b4e40be4","components/brand/Wordmark.jsx":"36cfb3da3aa2","components/chrome/AnnouncementBar.jsx":"112f21d182d0","components/chrome/MobileOrderBar.jsx":"9e8f45e9a64d","components/chrome/SiteFooter.jsx":"d9938fcef7d1","components/chrome/SiteHeader.jsx":"101831527ae4","components/chrome/Ticker.jsx":"24e0a7442641","components/core/BrandIcon.jsx":"85afeed7770c","components/core/Button.jsx":"0b76042af500","components/core/CheckerStrip.jsx":"21cd659c3d86","components/core/HalalBadge.jsx":"4128e6c08bd9","components/core/SectionNumber.jsx":"9afc2f124efa","components/core/Stamp.jsx":"865b2e4a8bf0","components/core/Sticker.jsx":"7dbe257f0f32","components/menu/MenuCategory.jsx":"84fdea43121a","components/menu/PizzaCard.jsx":"9b62864aaddc","ui_kits/website/HomeScreen.jsx":"343a10c8cf49","ui_kits/website/MenuScreen.jsx":"92b6f1ff52b3","ui_kits/website/VisitScreen.jsx":"e3d7bfca75a4","ui_kits/website/data.js":"58327b1c3137"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PizzaRattoDesignSystem_c589b8 = window.PizzaRattoDesignSystem_c589b8 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/PhotoCard.jsx
try { (() => {
const R = {
  rect: 0,
  rounded: "var(--radius-card)",
  circle: "50%",
  arch: "999px 999px 0 0",
  pill: "999px"
};
function PhotoCard({
  src,
  alt = "",
  shape = "rect",
  aspect = "4 / 5",
  rotate = 0,
  background = "var(--ratto-pink)",
  shadow = null,
  caption,
  width = "100%",
  style
}) {
  const round = shape === "circle";
  return /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      width,
      transform: rotate ? `rotate(${rotate}deg)` : undefined,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: round ? "1" : aspect,
      overflow: "hidden",
      background,
      borderRadius: R[shape] ?? 0,
      boxShadow: shadow ? `6px 6px 0 ${shadow}` : "none"
    }
  }, src && /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  })), caption && /*#__PURE__*/React.createElement("figcaption", {
    style: {
      marginTop: ".7rem",
      fontFamily: "var(--font-body)",
      fontSize: ".72rem",
      fontWeight: 600,
      letterSpacing: ".14em",
      textTransform: "uppercase",
      color: "inherit"
    }
  }, caption));
}
Object.assign(__ds_scope, { PhotoCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/PhotoCard.jsx", error: String((e && e.message) || e) }); }

// components/brand/PopShape.jsx
try { (() => {
function PopShape({
  shape = "circle",
  color = "var(--ratto-red)",
  accent = "var(--paper-cream)",
  size = 160,
  rotate = 0,
  style
}) {
  const st = {
    width: size,
    height: size,
    display: "block",
    flex: "0 0 auto",
    transform: rotate ? `rotate(${rotate}deg)` : undefined,
    ...style
  };
  const sh = {
    circle: /*#__PURE__*/React.createElement("circle", {
      cx: "50",
      cy: "50",
      r: "50",
      fill: color
    }),
    ring: /*#__PURE__*/React.createElement("circle", {
      cx: "50",
      cy: "50",
      r: "40",
      fill: "none",
      stroke: color,
      strokeWidth: "20"
    }),
    half: /*#__PURE__*/React.createElement("path", {
      d: "M0 50a50 50 0 0 1 100 0Z",
      fill: color
    }),
    quarter: /*#__PURE__*/React.createElement("path", {
      d: "M0 0h100A100 100 0 0 1 0 100Z",
      fill: color
    }),
    arch: /*#__PURE__*/React.createElement("path", {
      d: "M0 100V50a50 50 0 0 1 100 0v50Z",
      fill: color
    }),
    leaf: /*#__PURE__*/React.createElement("path", {
      d: "M2 50C20 12 80 12 98 50 80 88 20 88 2 50Z",
      fill: color
    }),
    bite: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "50",
      cy: "50",
      r: "50",
      fill: color
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "104",
      cy: "34",
      r: "20",
      fill: accent
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "100",
      cy: "64",
      r: "16",
      fill: accent
    })),
    fruit: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M50 22C38 8 6 10 4 44c-2 32 22 56 46 56s48-24 46-56C94 10 62 8 50 22Z",
      fill: color
    }), /*#__PURE__*/React.createElement("path", {
      d: "M50 22 52 2",
      stroke: accent === "var(--paper-cream)" ? "var(--ratto-brown)" : accent,
      strokeWidth: "3",
      strokeLinecap: "round"
    })),
    bitten: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M50 22C38 8 6 10 4 44c-2 32 22 56 46 56s48-24 46-56C94 10 62 8 50 22Z",
      fill: color
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "100",
      cy: "46",
      r: "18",
      fill: accent
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "94",
      cy: "74",
      r: "14",
      fill: accent
    })),
    slice: /*#__PURE__*/React.createElement("path", {
      d: "M50 4 96 96H4Z",
      fill: color
    }),
    pizza: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "50",
      cy: "50",
      r: "50",
      fill: color
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "50",
      cy: "50",
      r: "38",
      fill: accent
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "36",
      cy: "38",
      r: "8",
      fill: color
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "62",
      cy: "34",
      r: "6",
      fill: color
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "58",
      cy: "62",
      r: "9",
      fill: color
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "34",
      cy: "64",
      r: "5",
      fill: color
    })),
    sun: /*#__PURE__*/React.createElement(React.Fragment, null, Array.from({
      length: 16
    }).map((_, i) => /*#__PURE__*/React.createElement("path", {
      key: i,
      d: "M50 50 47 0h6Z",
      fill: color,
      transform: `rotate(${i * 22.5} 50 50)`
    })), /*#__PURE__*/React.createElement("circle", {
      cx: "50",
      cy: "50",
      r: "22",
      fill: color
    })),
    wheel: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "50",
      cy: "50",
      r: "44",
      fill: "none",
      stroke: color,
      strokeWidth: "12"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "50",
      cy: "50",
      r: "12",
      fill: color
    }))
  }[shape];
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 100",
    style: st,
    "aria-hidden": "true",
    overflow: "visible"
  }, sh);
}
Object.assign(__ds_scope, { PopShape });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/PopShape.jsx", error: String((e && e.message) || e) }); }

// components/brand/RulesCard.jsx
try { (() => {
const T = {
  red: ["var(--ratto-red)", "var(--paper-cream)", "var(--ratto-pink)"],
  brown: ["var(--ratto-brown)", "var(--paper-cream)", "var(--hot-orange)"],
  pink: ["var(--ratto-pink)", "var(--ratto-brown)", "var(--ratto-red)"],
  orange: ["var(--hot-orange)", "var(--ratto-brown)", "var(--paper-cream)"]
};
function RulesCard({
  title = "House rules",
  items = [],
  numbered = true,
  tone = "red",
  rotate = 0,
  style
}) {
  const [bg, fg, ac] = T[tone] || T.red;
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      padding: "1.8rem 1.8rem 1.4rem",
      color: fg,
      background: bg,
      borderRadius: "var(--radius-card)",
      transform: rotate ? `rotate(${rotate}deg)` : undefined,
      fontFamily: "var(--font-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      display: "block",
      marginBottom: ".9rem",
      color: ac,
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      fontSize: "1.6rem",
      lineHeight: 1
    }
  }, title), items.map((it, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      display: "flex",
      gap: ".9rem",
      alignItems: "baseline",
      padding: ".7rem 0",
      borderTop: "1.5px solid currentColor",
      fontWeight: 500,
      fontSize: "1rem"
    }
  }, numbered && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: ".72rem",
      fontWeight: 600,
      letterSpacing: ".14em",
      opacity: .8
    }
  }, String(i + 1).padStart(2, "0")), it)));
}
Object.assign(__ds_scope, { RulesCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/RulesCard.jsx", error: String((e && e.message) || e) }); }

// components/brand/Wordmark.jsx
try { (() => {
const SRC = {
  stacked: "assets/brand/pizza-ratto-wordmark.svg",
  banner: "assets/brand/wordmark-banner.svg",
  hero: "assets/logo/hero-logo-mascot.png",
  art: "assets/logo/pizza-ratto-logo-art.png",
  stencil: "assets/mascot/remi-vespa-stencil-original.png"
};
function Wordmark({
  variant = "stacked",
  assetBase = "",
  width = 120,
  rotate = 0,
  alt = "Pizza Ratto",
  style
}) {
  return /*#__PURE__*/React.createElement("img", {
    src: assetBase + (SRC[variant] || SRC.stacked),
    alt: alt,
    style: {
      width,
      height: "auto",
      display: "block",
      transform: rotate ? `rotate(${rotate}deg)` : undefined,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/chrome/AnnouncementBar.jsx
try { (() => {
function AnnouncementBar({
  items = ["Made fresh. Taken seriously by no one.", "Wood-fired in Salt River", "Mon–Sat 10:00–18:00"],
  tone = "brown",
  style
}) {
  const bg = tone === "red" ? "var(--ratto-red)" : "var(--ratto-brown)";
  return /*#__PURE__*/React.createElement("div", {
    role: "note",
    style: {
      overflow: "hidden",
      color: "var(--paper-cream)",
      background: bg,
      whiteSpace: "nowrap",
      textTransform: "uppercase",
      letterSpacing: ".16em",
      fontSize: ".68rem",
      fontWeight: 600,
      fontFamily: "var(--font-body)",
      textAlign: "center",
      padding: ".62rem 1rem",
      ...style
    }
  }, items.map((t, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      display: "inline-block",
      width: 6,
      height: 6,
      margin: "0 1rem",
      borderRadius: "50%",
      background: "var(--hot-orange)",
      verticalAlign: "middle"
    }
  }), t)));
}
Object.assign(__ds_scope, { AnnouncementBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/AnnouncementBar.jsx", error: String((e && e.message) || e) }); }

// components/chrome/Ticker.jsx
try { (() => {
function Ticker({
  text = "Italian soul ● Street-corner attitude ● Pizza, done properly ● ",
  duration = 22,
  tone = "red",
  animate = true,
  style
}) {
  const id = React.useMemo(() => "prtk" + Math.random().toString(36).slice(2, 7), []);
  const map = {
    red: ["var(--ratto-red)", "var(--paper-cream)"],
    hot: ["var(--hot-orange)", "var(--ratto-brown)"],
    brown: ["var(--ratto-brown)", "var(--ratto-pink)"],
    pink: ["var(--ratto-pink)", "var(--ratto-red)"]
  };
  const [bg, fg] = map[tone] || map.red;
  const run = text.repeat(4);
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      overflow: "hidden",
      padding: ".7rem 0",
      color: fg,
      background: bg,
      whiteSpace: "nowrap",
      fontFamily: "var(--font-display)",
      fontSize: "1.6rem",
      lineHeight: 1.1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("style", null, `@keyframes ${id}{to{transform:translateX(-50%)}}@media (prefers-reduced-motion:reduce){.${id}{animation:none!important}}`), /*#__PURE__*/React.createElement("div", {
    className: id,
    style: {
      display: "flex",
      width: "max-content",
      animation: animate ? `${id} ${duration}s linear infinite` : "none"
    }
  }, /*#__PURE__*/React.createElement("span", null, run), /*#__PURE__*/React.createElement("span", null, run)));
}
Object.assign(__ds_scope, { Ticker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/Ticker.jsx", error: String((e && e.message) || e) }); }

// components/core/BrandIcon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const PATHS = {
  whatsapp: {
    vb: "0 0 24 24",
    d: "M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.39-1.47-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.92-2.21-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.23 1.36.2 1.87.12.57-.09 1.76-.72 2.01-1.41.25-.69.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.78h-.01a9.84 9.84 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26A9.9 9.9 0 0 1 12.05 2a9.82 9.82 0 0 1 6.99 2.9 9.820 9.82 0 0 1 2.9 7c0 5.45-4.44 9.88-9.89 9.88M20.47 3.49A11.82 11.82 0 0 0 12.06 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.9 11.9 0 0 0 5.69 1.45h.01c6.56 0 11.89-5.34 11.89-11.9 0-3.18-1.23-6.16-3.48-8.41"
  },
  call: {
    vb: "0 0 24 24",
    d: "M6.62 10.79a15.46 15.46 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.33.57 3.57.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.61 21 3 13.39 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1.02l-2.2 2.2Z"
  },
  ubereats: {
    vb: "0 0 36 24",
    d: "M3 4h13v3H6v3h9v3H6v4h10v3H3V4Zm17 0h13v3H23v3h9v3h-9v4h10v3H20V4Z"
  }
};
function BrandIcon({
  name = "call",
  size = "1.15em",
  color = "currentColor",
  style,
  title
}) {
  const s = {
    width: name === "ubereats" ? `calc(${typeof size === "number" ? size + "px" : size} * 1.5)` : size,
    height: size,
    flex: "0 0 auto",
    display: "inline-block",
    ...style
  };
  const aria = title ? {
    role: "img",
    "aria-label": title
  } : {
    "aria-hidden": true
  };
  if (name === "instagram") {
    return /*#__PURE__*/React.createElement("svg", _extends({
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: color,
      strokeWidth: "2",
      style: s
    }, aria), /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "3",
      width: "18",
      height: "18",
      rx: "5"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "4"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "17.5",
      cy: "6.5",
      r: "1",
      fill: color,
      stroke: "none"
    }));
  }
  const p = PATHS[name] || PATHS.call;
  return /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: p.vb,
    fill: color,
    style: s
  }, aria), /*#__PURE__*/React.createElement("path", {
    d: p.d
  }));
}
Object.assign(__ds_scope, { BrandIcon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/BrandIcon.jsx", error: String((e && e.message) || e) }); }

// components/chrome/MobileOrderBar.jsx
try { (() => {
function MobileOrderBar({
  whatsappUrl = "https://wa.me/27825250380",
  phone = "+27825250380",
  uberUrl = "https://www.ubereats.com/za/store/pizza-ratto/c2X95IU_SWaBTX_qeHpCng",
  style
}) {
  const a = (bg, fg) => ({
    minHeight: 64,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: ".3rem",
    color: fg,
    background: bg,
    textDecoration: "none",
    fontSize: ".66rem",
    fontWeight: 600,
    letterSpacing: ".14em",
    textTransform: "uppercase"
  });
  return /*#__PURE__*/React.createElement("nav", {
    "aria-label": "Quick order actions",
    style: {
      display: "grid",
      gridTemplateColumns: "1.3fr 1fr 1fr",
      fontFamily: "var(--font-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: whatsappUrl,
    style: a("var(--ratto-red)", "var(--paper-cream)")
  }, /*#__PURE__*/React.createElement(__ds_scope.BrandIcon, {
    name: "whatsapp",
    size: 20
  }), "WhatsApp"), /*#__PURE__*/React.createElement("a", {
    href: "tel:" + phone,
    style: a("var(--hot-orange)", "var(--ratto-brown)")
  }, /*#__PURE__*/React.createElement(__ds_scope.BrandIcon, {
    name: "call",
    size: 20
  }), "Call"), /*#__PURE__*/React.createElement("a", {
    href: uberUrl,
    style: a("var(--ratto-brown)", "var(--paper-cream)")
  }, /*#__PURE__*/React.createElement(__ds_scope.BrandIcon, {
    name: "ubereats",
    size: 18
  }), "Uber Eats"));
}
Object.assign(__ds_scope, { MobileOrderBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/MobileOrderBar.jsx", error: String((e && e.message) || e) }); }

// components/chrome/SiteFooter.jsx
try { (() => {
function SiteFooter({
  assetBase = "",
  tagline = "Italian soul. Street-corner attitude.",
  address = "20 Brickfield Road, Salt River, Cape Town",
  hours = "Monday–Saturday, 10:00–18:00",
  phone = "082 525 0380",
  year = new Date().getFullYear(),
  instagramUrl = "https://www.instagram.com/pizza_ratto/",
  style
}) {
  const lbl = {
    margin: "0 0 .5rem",
    fontSize: ".68rem",
    fontWeight: 600,
    letterSpacing: ".16em",
    textTransform: "uppercase",
    color: "var(--hot-orange)"
  };
  const p = {
    margin: 0,
    fontSize: ".95rem",
    lineHeight: 1.5
  };
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      padding: "4rem clamp(1.25rem,5vw,5rem) 2.5rem",
      color: "var(--paper-cream)",
      background: "var(--ratto-brown)",
      fontFamily: "var(--font-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,1.4fr) repeat(3,minmax(0,1fr))",
      gap: "2rem",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-headline)",
      fontWeight: 700,
      fontSize: "clamp(2rem,3.4vw,3rem)",
      letterSpacing: "-.035em",
      lineHeight: .95,
      color: "var(--ratto-pink)"
    }
  }, tagline)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: lbl
  }, "Where"), /*#__PURE__*/React.createElement("p", {
    style: p
  }, address)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: lbl
  }, "When"), /*#__PURE__*/React.createElement("p", {
    style: p
  }, hours)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: lbl
  }, "Call / WhatsApp"), /*#__PURE__*/React.createElement("p", {
    style: {
      ...p,
      fontFamily: "var(--font-display)",
      fontSize: "1.4rem"
    }
  }, phone))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "1rem",
      marginTop: "3rem",
      paddingTop: "1.2rem",
      borderTop: "1.5px solid rgba(245,240,230,.35)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: ".72rem",
      letterSpacing: ".08em"
    }
  }, "\xA9 ", year, " Pizza Ratto \xB7 Built with fire, not focus groups."), /*#__PURE__*/React.createElement("a", {
    href: instagramUrl,
    target: "_blank",
    rel: "noreferrer",
    "aria-label": "Pizza Ratto on Instagram @pizza_ratto",
    style: {
      width: 44,
      height: 44,
      display: "grid",
      placeItems: "center",
      color: "var(--ratto-brown)",
      background: "var(--ratto-pink)",
      borderRadius: "50%"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.BrandIcon, {
    name: "instagram",
    size: 22
  }))));
}
Object.assign(__ds_scope, { SiteFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const V = {
  primary: ["var(--ratto-red)", "var(--paper-cream)", "var(--ratto-brown)", "var(--paper-cream)"],
  hot: ["var(--hot-orange)", "var(--ratto-brown)", "var(--ratto-brown)", "var(--paper-cream)"],
  dark: ["var(--ratto-brown)", "var(--paper-cream)", "var(--ratto-red)", "var(--paper-cream)"],
  cream: ["var(--paper-cream)", "var(--ratto-brown)", "var(--ratto-pink)", "var(--ratto-brown)"],
  outline: ["transparent", "var(--ratto-brown)", "var(--ratto-brown)", "var(--paper-cream)"],
  street: ["var(--ratto-red)", "var(--paper-cream)", "var(--hot-orange)", "var(--ratto-brown)"]
};
function Button({
  variant = "primary",
  size = "md",
  icon,
  href,
  onClick,
  disabled = false,
  block = false,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const [bg, fg, hbg, hfg] = V[variant] || V.primary;
  const live = hover && !disabled;
  const sm = size === "sm";
  const street = variant === "street";
  const outline = variant === "outline";
  const s = {
    minHeight: sm ? 40 : 52,
    padding: sm ? ".55rem 1.1rem" : ".85rem 1.6rem",
    display: block ? "flex" : "inline-flex",
    width: block ? "100%" : undefined,
    alignItems: "center",
    justifyContent: "center",
    gap: ".55rem",
    color: live ? hfg : fg,
    background: live ? hbg : bg,
    border: outline ? "1.5px solid var(--ratto-brown)" : street ? "3px solid var(--ratto-brown)" : "0",
    borderRadius: "var(--radius-pill)",
    boxShadow: street ? "6px 6px 0 var(--ratto-brown)" : "none",
    fontFamily: "var(--font-body)",
    fontSize: sm ? ".74rem" : ".86rem",
    fontWeight: 600,
    letterSpacing: ".1em",
    textTransform: "uppercase",
    lineHeight: 1,
    textDecoration: "none",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? .4 : 1,
    transform: press && !disabled ? "scale(.97)" : street && live ? "translate(-2px,-2px)" : "none",
    transition: "background .15s ease, color .15s ease, transform .15s ease",
    boxSizing: "border-box",
    ...style
  };
  const Tag = href ? "a" : "button";
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    onClick: disabled ? undefined : onClick,
    disabled: Tag === "button" ? disabled : undefined,
    "aria-disabled": disabled || undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: s
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.BrandIcon, {
    name: icon
  }), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/chrome/SiteHeader.jsx
try { (() => {
function SiteHeader({
  assetBase = "",
  links = [{
    label: "Menu",
    href: "#menu"
  }, {
    label: "About",
    href: "#story"
  }, {
    label: "Visit",
    href: "#visit"
  }],
  active,
  onNavigate,
  ctaLabel = "Order now",
  ctaHref = "https://wa.me/27825250380",
  style
}) {
  const [hov, setHov] = React.useState(null);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      minHeight: 72,
      padding: "0 clamp(1rem,4vw,4rem)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "1.5rem",
      background: "var(--paper-cream)",
      borderBottom: "1.5px solid var(--ratto-brown)",
      color: "var(--ratto-brown)",
      fontFamily: "var(--font-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    "aria-label": "Pizza Ratto home",
    onClick: onNavigate ? e => {
      e.preventDefault();
      onNavigate("top");
    } : undefined,
    style: {
      display: "grid",
      placeItems: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Wordmark, {
    assetBase: assetBase,
    width: 60,
    alt: ""
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: "2.4rem",
      marginLeft: "auto",
      textTransform: "uppercase",
      fontSize: ".76rem",
      fontWeight: 600,
      letterSpacing: ".16em"
    }
  }, links.map(l => {
    const on = hov === l.label || active === l.label;
    return /*#__PURE__*/React.createElement("a", {
      key: l.label,
      href: l.href,
      onClick: onNavigate ? e => {
        e.preventDefault();
        onNavigate(l.href.replace("#", ""));
      } : undefined,
      onMouseEnter: () => setHov(l.label),
      onMouseLeave: () => setHov(null),
      style: {
        minHeight: 44,
        display: "inline-flex",
        alignItems: "center",
        gap: ".5rem",
        color: on ? "var(--ratto-red)" : "inherit",
        textDecoration: "none"
      }
    }, /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        width: 7,
        height: 7,
        borderRadius: "50%",
        background: active === l.label ? "var(--ratto-red)" : "transparent"
      }
    }), l.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    icon: "whatsapp",
    href: ctaHref
  }, ctaLabel));
}
Object.assign(__ds_scope, { SiteHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// components/core/CheckerStrip.jsx
try { (() => {
const P = {
  ink: ["var(--ratto-brown)", "var(--paper-cream)"],
  hot: ["var(--ratto-red)", "var(--paper-cream)"],
  pink: ["var(--ratto-red)", "var(--ratto-pink)"],
  orange: ["var(--hot-orange)", "var(--paper-cream)"],
  stencil: ["var(--ink-black)", "var(--white)"]
};
function CheckerStrip({
  variant = "ink",
  size = 28,
  rows = 1,
  rotate = 0,
  style
}) {
  const [a, b] = P[variant] || P.ink;
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      width: "100%",
      height: size * rows,
      background: `repeating-conic-gradient(${a} 0 25%, ${b} 0 50%) 0 / ${size}px ${size}px`,
      transform: rotate ? `rotate(${rotate}deg)` : undefined,
      ...style
    }
  });
}
Object.assign(__ds_scope, { CheckerStrip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/CheckerStrip.jsx", error: String((e && e.message) || e) }); }

// components/core/HalalBadge.jsx
try { (() => {
function HalalBadge({
  size = 200,
  label = "HALAL",
  color = "var(--ink-black)",
  background = "var(--white)",
  style
}) {
  const k = size / 200;
  return /*#__PURE__*/React.createElement("div", {
    role: "img",
    "aria-label": label,
    style: {
      position: "relative",
      width: size,
      height: size,
      flex: "0 0 auto",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 10 * k,
      top: 10 * k,
      width: 180 * k,
      height: 180 * k,
      borderRadius: "50%",
      background,
      boxShadow: `inset 0 0 0 ${6 * k}px ${color}`,
      display: "grid",
      placeItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontWeight: 900,
      fontSize: 28 * k,
      lineHeight: 1,
      color,
      letterSpacing: ".02em"
    }
  }, label)));
}
Object.assign(__ds_scope, { HalalBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/HalalBadge.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionNumber.jsx
try { (() => {
function SectionNumber({
  number,
  label,
  color = "inherit",
  rule = true,
  style
}) {
  return /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 1.4rem",
      display: "flex",
      alignItems: "center",
      gap: ".9rem",
      color,
      fontFamily: "var(--font-body)",
      fontSize: ".78rem",
      fontWeight: 600,
      lineHeight: 1.2,
      letterSpacing: ".16em",
      textTransform: "uppercase",
      ...style
    }
  }, number != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "1.1rem",
      letterSpacing: 0
    }
  }, String(number).padStart(2, "0")), number != null && rule && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 28,
      height: 1.5,
      background: "currentColor"
    }
  }), /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { SectionNumber });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionNumber.jsx", error: String((e && e.message) || e) }); }

// components/core/Stamp.jsx
try { (() => {
const T = {
  hot: ["var(--hot-orange)", "var(--ratto-brown)"],
  pink: ["var(--ratto-pink)", "var(--ratto-brown)"],
  red: ["var(--ratto-red)", "var(--paper-cream)"],
  cream: ["var(--paper-cream)", "var(--ratto-brown)"],
  brown: ["var(--ratto-brown)", "var(--paper-cream)"]
};
function Stamp({
  top,
  main,
  sub,
  tone = "hot",
  size = 120,
  rotate = 8,
  style
}) {
  const [bg, fg] = T[tone] || T.hot;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      padding: size * .1,
      display: "grid",
      placeContent: "center",
      gap: size * .02,
      textAlign: "center",
      color: fg,
      background: bg,
      borderRadius: "50%",
      transform: `rotate(${rotate}deg)`,
      boxSizing: "border-box",
      flex: "0 0 auto",
      ...style
    }
  }, top && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontWeight: 600,
      fontSize: size * .075,
      letterSpacing: ".16em",
      textTransform: "uppercase"
    }
  }, top), main && /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      fontSize: size * .2,
      lineHeight: .95
    }
  }, main), sub && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontWeight: 600,
      fontSize: size * .075,
      letterSpacing: ".12em",
      textTransform: "uppercase"
    }
  }, sub));
}
Object.assign(__ds_scope, { Stamp });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stamp.jsx", error: String((e && e.message) || e) }); }

// components/core/Sticker.jsx
try { (() => {
const base = {
  fontFamily: "var(--font-body)",
  fontWeight: 600,
  letterSpacing: ".14em",
  textTransform: "uppercase",
  fontSize: ".68rem",
  lineHeight: 1,
  padding: ".42rem .7rem",
  borderRadius: "var(--radius-pill)"
};
const V = {
  note: {
    ...base,
    color: "var(--paper-cream)",
    background: "var(--ratto-red)"
  },
  price: {
    ...base,
    color: "var(--paper-cream)",
    background: "var(--ratto-brown)"
  },
  pink: {
    ...base,
    color: "var(--ratto-brown)",
    background: "var(--ratto-pink)"
  },
  hot: {
    ...base,
    color: "var(--ratto-brown)",
    background: "var(--hot-orange)"
  },
  outline: {
    ...base,
    color: "var(--ratto-brown)",
    background: "transparent",
    boxShadow: "inset 0 0 0 1.5px var(--ratto-brown)"
  },
  aside: {
    color: "var(--ratto-red)",
    fontFamily: "var(--font-display)",
    fontSize: "1.35rem",
    lineHeight: 1.05,
    rot: -4
  }
};
function Sticker({
  variant = "note",
  rotate,
  children,
  style
}) {
  const {
    rot = 0,
    ...v
  } = V[variant] || V.note;
  const r = rotate ?? rot;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      width: "max-content",
      maxWidth: "100%",
      boxSizing: "border-box",
      ...v,
      transform: r ? `rotate(${r}deg)` : undefined,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Sticker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Sticker.jsx", error: String((e && e.message) || e) }); }

// components/menu/MenuCategory.jsx
try { (() => {
const TONE = {
  orange: "var(--hot-orange)",
  cream: "var(--paper-cream)",
  pink: "var(--ratto-pink)",
  white: "var(--white)"
};
function MenuCategory({
  name,
  kicker,
  tone = "orange",
  mark,
  groups = [],
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "clamp(1.6rem,3vw,2.6rem)",
      background: TONE[tone] || tone,
      color: "var(--ratto-brown)",
      fontFamily: "var(--font-body)",
      borderRadius: "var(--radius-card)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: "1rem",
      paddingBottom: "1rem",
      borderBottom: "1.5px solid var(--ratto-brown)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      color: "var(--ratto-red)",
      fontFamily: "var(--font-headline)",
      fontWeight: 700,
      fontSize: "clamp(2.2rem,3.4vw,3.2rem)",
      lineHeight: .92,
      letterSpacing: "-.035em"
    }
  }, name), kicker && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: ".55rem 0 0",
      fontSize: ".9rem",
      lineHeight: 1.35
    }
  }, kicker)), mark && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: "0 0 auto",
      width: 64,
      display: "grid",
      placeItems: "center"
    }
  }, mark)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "1.1rem",
      marginTop: "1.1rem"
    }
  }, groups.map((g, gi) => /*#__PURE__*/React.createElement("div", {
    key: gi,
    style: {
      display: "grid",
      gridTemplateColumns: "64px minmax(0,1fr)",
      gap: ".9rem",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      marginTop: ".55rem",
      fontFamily: "var(--font-display)",
      fontSize: "1.25rem",
      color: "var(--ratto-red)",
      lineHeight: 1
    }
  }, g.price), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 0
    }
  }, (g.items || []).map((it, ii) => /*#__PURE__*/React.createElement("li", {
    key: ii,
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: "1rem",
      padding: ".55rem 0",
      borderBottom: "1px solid rgba(66,18,18,.28)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: ".95rem",
      fontWeight: 600,
      letterSpacing: ".06em",
      textTransform: "uppercase"
    }
  }, it.name), it.description && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: ".2rem 0 0",
      fontSize: ".85rem",
      lineHeight: 1.35
    }
  }, it.description), it.note && /*#__PURE__*/React.createElement("small", {
    style: {
      display: "block",
      marginTop: ".25rem",
      color: "var(--ratto-red)",
      fontSize: ".78rem"
    }
  }, it.note)), it.price != null && /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--ratto-red)",
      fontWeight: 600,
      whiteSpace: "nowrap"
    }
  }, typeof it.price === "number" ? "R" + it.price : it.price))))))));
}
Object.assign(__ds_scope, { MenuCategory });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/menu/MenuCategory.jsx", error: String((e && e.message) || e) }); }

// components/menu/PizzaCard.jsx
try { (() => {
function PizzaCard({
  name,
  price,
  description,
  note,
  featured = false,
  image,
  alt = "",
  layout = "stack",
  style
}) {
  const [hover, setHover] = React.useState(false);
  const priceText = typeof price === "number" ? "R" + price : price;
  const row = layout === "row";
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      minWidth: 0,
      display: "grid",
      gridTemplateColumns: row ? "112px minmax(0,1fr)" : "1fr",
      gap: row ? "1.2rem" : "1.1rem",
      alignItems: row ? "center" : "start",
      color: "var(--ratto-brown)",
      fontFamily: "var(--font-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      aspectRatio: "1",
      borderRadius: "50%",
      overflow: "hidden",
      background: image ? "var(--ratto-pink)" : "var(--ratto-red)",
      display: "grid",
      placeItems: "center",
      transform: hover ? "rotate(-6deg)" : "none",
      transition: "transform .45s cubic-bezier(.2,.7,.2,1)"
    }
  }, image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: alt,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--paper-cream)",
      fontFamily: "var(--font-display)",
      fontSize: "1.1rem",
      textAlign: "center",
      lineHeight: 1.05
    }
  }, "photo", /*#__PURE__*/React.createElement("br", null), "coming hot")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      gap: ".8rem",
      paddingBottom: ".5rem",
      borderBottom: "1.5px solid var(--ratto-brown)"
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: row ? "1.6rem" : "clamp(1.6rem,2.4vw,2.2rem)",
      fontWeight: 400,
      lineHeight: 1
    }
  }, name), /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--ratto-red)",
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      fontSize: row ? "1.3rem" : "1.5rem",
      whiteSpace: "nowrap"
    }
  }, priceText)), description && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: ".55rem 0 0",
      fontSize: ".98rem",
      lineHeight: 1.4
    }
  }, description), (note || featured) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: ".4rem",
      marginTop: ".7rem"
    }
  }, note && /*#__PURE__*/React.createElement("small", {
    style: {
      padding: ".38rem .65rem",
      color: "var(--paper-cream)",
      background: "var(--ratto-red)",
      borderRadius: 999,
      fontSize: ".64rem",
      fontWeight: 600,
      letterSpacing: ".12em",
      textTransform: "uppercase",
      lineHeight: 1
    }
  }, note), featured && /*#__PURE__*/React.createElement("small", {
    style: {
      padding: ".38rem .65rem",
      color: "var(--ratto-brown)",
      background: "var(--hot-orange)",
      borderRadius: 999,
      fontSize: ".64rem",
      fontWeight: 600,
      letterSpacing: ".12em",
      textTransform: "uppercase",
      lineHeight: 1
    }
  }, "House favourite"))));
}
Object.assign(__ds_scope, { PizzaCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/menu/PizzaCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Button,
  Stamp,
  SectionNumber,
  RulesCard,
  PizzaCard,
  PhotoCard,
  PopShape,
  Ticker,
  Sticker
} = window.PizzaRattoDesignSystem_c589b8;
const A = "../../";
const H = {
  fontFamily: "var(--font-headline)",
  fontWeight: 700,
  letterSpacing: "-.035em",
  lineHeight: .92,
  margin: 0
};
function Hero({
  go
}) {
  const b = window.PR_DATA.business;
  return /*#__PURE__*/React.createElement("section", {
    className: "pr-grain",
    style: {
      position: "relative",
      overflow: "hidden",
      background: "var(--paper-cream)",
      padding: "clamp(3rem,6vw,6rem) var(--section-pad-x) clamp(3rem,5vw,5rem)",
      display: "grid",
      gridTemplateColumns: "minmax(0,1.1fr) minmax(0,.9fr)",
      gap: "2rem",
      alignItems: "center",
      minHeight: 620
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement(SectionNumber, {
    label: "Wood-fired \xB7 Salt River \xB7 Cape Town",
    color: "var(--ratto-red)"
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      ...H,
      fontSize: "var(--type-h1)",
      color: "var(--ratto-brown)"
    }
  }, "Pizza with", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--ratto-red)"
    }
  }, "street-corner"), /*#__PURE__*/React.createElement("br", null), "attitude."), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: 420,
      margin: "1.6rem 0 0",
      fontSize: "var(--type-lead)",
      lineHeight: 1.45
    }
  }, "Hand-stretched, fired hot and ready for collection."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: ".8rem",
      marginTop: "2rem"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: "whatsapp",
    href: b.whatsapp
  }, "Order on WhatsApp"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    onClick: () => go("menu")
  }, "See the menu")), /*#__PURE__*/React.createElement("a", {
    href: "tel:" + b.phoneIntl,
    style: {
      display: "inline-block",
      marginTop: "1.6rem",
      fontFamily: "var(--font-display)",
      fontSize: "1.9rem",
      color: "var(--ratto-brown)",
      textDecoration: "none"
    }
  }, b.phone)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: "1",
      maxWidth: 560,
      justifySelf: "end",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: "4% 0 0 6%",
      borderRadius: "50%",
      background: "var(--ratto-red)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      right: "-6%",
      top: "-2%",
      width: "26%",
      aspectRatio: "1",
      borderRadius: "50%",
      background: "var(--paper-cream)"
    }
  }), /*#__PURE__*/React.createElement("img", {
    src: A + "assets/mascot/remi-vespa-stencil-original.png",
    alt: "Remi the rat riding a Vespa while eating pizza",
    style: {
      position: "absolute",
      left: "-8%",
      bottom: "4%",
      width: "112%",
      mixBlendMode: "multiply"
    }
  }), /*#__PURE__*/React.createElement(Stamp, {
    top: "Open",
    main: "Mon\u2013Sat",
    sub: "10 \u2014 18",
    tone: "hot",
    style: {
      position: "absolute",
      left: "2%",
      top: "2%"
    }
  })));
}
function Story() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--hot-orange)",
      color: "var(--ratto-brown)",
      padding: "var(--section-pad-y) var(--section-pad-x)",
      display: "grid",
      gridTemplateColumns: "minmax(0,1.3fr) minmax(0,.7fr)",
      gap: "clamp(2rem,6vw,6rem)",
      alignItems: "end"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionNumber, {
    number: 1,
    label: "What we\u2019re about"
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...H,
      fontSize: "var(--type-h2)"
    }
  }, "Respect fire,", /*#__PURE__*/React.createElement("br", null), "time & tomatoes."), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: 600,
      margin: "1.6rem 0 0",
      fontSize: "var(--type-lead)",
      lineHeight: 1.45
    }
  }, "We\u2019re not saving the world. We\u2019re making it better one pizza at a time. Dough stretched by hand. Proper ingredients. Big Bertha running hot. No gimmicks.")), /*#__PURE__*/React.createElement(RulesCard, {
    tone: "brown",
    items: ["Hand-stretched", "Wood-fired", "Proper ingredients", "Zero fuss"]
  }));
}
function MenuTeaser({
  go
}) {
  const picks = window.PR_DATA.pizzas.filter(p => ["Sprint", "Arcobaleno", "Rally"].includes(p.name));
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--paper-cream)",
      padding: "var(--section-pad-y) var(--section-pad-x)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      gap: "2rem",
      marginBottom: "3rem"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionNumber, {
    number: 2,
    label: "The important bit",
    color: "var(--ratto-red)"
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...H,
      fontSize: "var(--type-h2)",
      color: "var(--ratto-red)"
    }
  }, "Pick your ride."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "1rem 0 0",
      fontSize: "1.05rem"
    }
  }, "Twelve rides. One very hot oven.")), /*#__PURE__*/React.createElement(Button, {
    variant: "dark",
    onClick: () => go("menu")
  }, "Full menu")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr))",
      gap: "clamp(1.4rem,3vw,3rem)"
    }
  }, picks.map(p => /*#__PURE__*/React.createElement(PizzaCard, _extends({
    key: p.name
  }, p, {
    image: A + "assets/photos/" + p.img + ".webp",
    alt: p.name + " pizza"
  })))));
}
function Ingredients() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--ratto-pink)",
      padding: "var(--section-pad-y) var(--section-pad-x)",
      display: "grid",
      gridTemplateColumns: "minmax(0,.9fr) minmax(0,1.1fr)",
      gap: "clamp(2rem,6vw,6rem)",
      alignItems: "center",
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(PhotoCard, {
    shape: "arch",
    aspect: "4 / 5",
    src: A + "assets/photos/feast-landscape.webp",
    alt: "A full Pizza Ratto table spread"
  }), /*#__PURE__*/React.createElement(PopShape, {
    shape: "leaf",
    color: "var(--basil-green)",
    size: 110,
    rotate: -28,
    style: {
      position: "absolute",
      right: "-6%",
      top: "-4%"
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionNumber, {
    number: 3,
    label: "Built different",
    color: "var(--ratto-red)"
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...H,
      fontSize: "var(--type-h2)",
      color: "var(--ratto-red)"
    }
  }, "Proper ingredients.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--ratto-brown)"
    }
  }, "Questionable mascot.")), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: 560,
      margin: "1.6rem 0 1.4rem",
      fontSize: "1.1rem",
      lineHeight: 1.5
    }
  }, "Our dough is stretched by hand and fired with intent. Italian mozzarella comes from Puglia. Our meat toppings are halal and sourced from Mubarak Food Emporium."), /*#__PURE__*/React.createElement(Sticker, {
    variant: "aside"
  }, "No shortcuts. No sad crusts.")));
}
function HomeScreen({
  go
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Hero, {
    go: go
  }), /*#__PURE__*/React.createElement(Ticker, null), /*#__PURE__*/React.createElement(Story, null), /*#__PURE__*/React.createElement(MenuTeaser, {
    go: go
  }), /*#__PURE__*/React.createElement(Ingredients, null));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/MenuScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  SectionNumber: MSec,
  PizzaCard: MPizza,
  MenuCategory: MCat,
  Sticker: MStk,
  HalalBadge: MHalal
} = window.PizzaRattoDesignSystem_c589b8;
const MA = "../../";
function MenuScreen() {
  const [filter, setFilter] = React.useState("All");
  const D = window.PR_DATA;
  const list = D.pizzas.filter(p => filter === "All" || (filter === "Favourites" ? p.featured : filter === "Specials" ? !!p.note : !p.note));
  const chip = f => /*#__PURE__*/React.createElement("button", {
    key: f,
    onClick: () => setFilter(f),
    style: {
      minHeight: 40,
      padding: "0 1.1rem",
      borderRadius: 999,
      border: "1.5px solid var(--ratto-brown)",
      background: filter === f ? "var(--ratto-brown)" : "transparent",
      color: filter === f ? "var(--paper-cream)" : "var(--ratto-brown)",
      fontFamily: "var(--font-body)",
      fontSize: ".74rem",
      fontWeight: 600,
      letterSpacing: ".14em",
      textTransform: "uppercase",
      cursor: "pointer"
    }
  }, f);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
    className: "pr-grain",
    style: {
      background: "var(--paper-cream)",
      padding: "var(--section-pad-y) var(--section-pad-x)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      gap: "2rem",
      paddingBottom: "2rem",
      borderBottom: "1.5px solid var(--ratto-brown)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(MSec, {
    label: "Twelve rides. One very hot oven.",
    color: "var(--ratto-red)"
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-headline)",
      fontWeight: 700,
      letterSpacing: "-.04em",
      lineHeight: .9,
      margin: 0,
      fontSize: "var(--type-mega)",
      color: "var(--ratto-red)"
    }
  }, "pizza")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "1rem"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: MA + "assets/brand/red-pizza-slice.svg",
    alt: "",
    style: {
      width: 64
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: ".74rem",
      fontWeight: 600,
      letterSpacing: ".16em",
      textTransform: "uppercase",
      lineHeight: 1.5
    }
  }, "Wood-fired", /*#__PURE__*/React.createElement("br", null), "by Big Bertha"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: ".6rem",
      margin: "1.8rem 0 3rem"
    }
  }, ["All", "Classics", "Specials", "Favourites"].map(chip)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr))",
      gap: "clamp(2rem,4vw,4rem) clamp(1.4rem,3vw,3rem)"
    }
  }, list.map(p => /*#__PURE__*/React.createElement(MPizza, _extends({
    key: p.name
  }, p, {
    image: MA + "assets/photos/" + p.img + ".webp",
    alt: p.name + " pizza"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "1.4rem",
      marginTop: "3.5rem"
    }
  }, /*#__PURE__*/React.createElement(MStk, {
    variant: "hot",
    style: {
      fontSize: ".8rem",
      padding: ".7rem 1.1rem"
    }
  }, "Hot honey & rat sauce \xB7 R15 each"), /*#__PURE__*/React.createElement(MHalal, {
    size: 84,
    color: "var(--ratto-brown)",
    background: "var(--paper-cream)"
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--ratto-brown)",
      padding: "var(--section-pad-y) var(--section-pad-x)"
    }
  }, /*#__PURE__*/React.createElement(MSec, {
    number: 2,
    label: "Caff\xE8 \xB7 Bevande \xB7 Dolci",
    color: "var(--hot-orange)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr))",
      gap: "1.2rem",
      alignItems: "start"
    }
  }, D.sides.map(c => /*#__PURE__*/React.createElement(MCat, _extends({
    key: c.name
  }, c, {
    mark: c.mark ? /*#__PURE__*/React.createElement("img", {
      src: MA + "assets/brand/" + c.mark + ".svg",
      alt: "",
      style: {
        width: 44
      }
    }) : null
  }))))));
}
window.MenuScreen = MenuScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/MenuScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/VisitScreen.jsx
try { (() => {
const {
  SectionNumber: VSec,
  Button: VBtn,
  PhotoCard: VPhoto,
  Stamp: VStamp,
  PopShape: VShape
} = window.PizzaRattoDesignSystem_c589b8;
const VA = "../../";
function VisitScreen() {
  const b = window.PR_DATA.business;
  const row = (k, v) => /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "1.1rem 0 1.3rem",
      borderTop: "1.5px solid var(--ratto-pink)"
    }
  }, /*#__PURE__*/React.createElement("dt", {
    style: {
      color: "var(--hot-orange)",
      fontSize: ".7rem",
      fontWeight: 600,
      letterSpacing: ".16em",
      textTransform: "uppercase"
    }
  }, k), /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: ".5rem 0 0",
      fontSize: "1.2rem",
      fontWeight: 500
    }
  }, v));
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--ratto-red)",
      color: "var(--paper-cream)",
      padding: "var(--section-pad-y) var(--section-pad-x)",
      display: "grid",
      gridTemplateColumns: "minmax(0,1.1fr) minmax(0,.9fr)",
      gap: "clamp(2rem,6vw,6rem)",
      alignItems: "center",
      minHeight: 640
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(VSec, {
    number: 5,
    label: "Find the fire",
    color: "var(--ratto-pink)"
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-headline)",
      fontWeight: 700,
      letterSpacing: "-.035em",
      lineHeight: .92,
      margin: 0,
      fontSize: "var(--type-h1)",
      color: "var(--paper-cream)"
    }
  }, "Salt River.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--ratto-pink)"
    }
  }, "Come say ciao.")), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: 520,
      margin: "1.6rem 0 2rem",
      fontSize: "var(--type-lead)",
      lineHeight: 1.45
    }
  }, "Fresh from the oven. Straight to your face \u2014 collection only."), /*#__PURE__*/React.createElement("dl", {
    style: {
      margin: 0,
      maxWidth: 520
    }
  }, row("Where", b.location), row("When", b.hours), row("Call / WhatsApp", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "1.6rem"
    }
  }, b.phone))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: ".8rem",
      marginTop: "1.6rem"
    }
  }, /*#__PURE__*/React.createElement(VBtn, {
    variant: "cream",
    icon: "whatsapp",
    href: b.whatsapp
  }, "WhatsApp an order"), /*#__PURE__*/React.createElement(VBtn, {
    variant: "hot",
    icon: "ubereats",
    href: b.uber
  }, "Uber Eats"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(VPhoto, {
    shape: "arch",
    aspect: "4 / 5",
    src: VA + "assets/photos/interior.webp",
    alt: "Pizza Ratto dining room with a Vespa",
    background: "var(--ratto-pink)"
  }), /*#__PURE__*/React.createElement(VShape, {
    shape: "wheel",
    color: "var(--paper-cream)",
    size: 120,
    style: {
      position: "absolute",
      left: "-10%",
      bottom: "6%"
    }
  }), /*#__PURE__*/React.createElement(VStamp, {
    tone: "pink",
    top: "Collection",
    main: "only",
    rotate: -8,
    style: {
      position: "absolute",
      right: "-4%",
      top: "8%"
    }
  }))));
}
window.VisitScreen = VisitScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/VisitScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.js
try { (() => {
window.PR_DATA = {
  business: {
    phone: "082 525 0380",
    phoneIntl: "+27825250380",
    location: "20 Brickfield Road, Salt River, Cape Town",
    hours: "Monday–Saturday, 10:00–18:00",
    whatsapp: "https://wa.me/27825250380",
    uber: "https://www.ubereats.com/za/store/pizza-ratto/c2X95IU_SWaBTX_qeHpCng",
    instagram: "https://www.instagram.com/pizza_ratto/"
  },
  pizzas: [{
    name: "Bianca & Dip",
    description: "EVOO, rosemary, sea salt and fresh dip",
    price: 40,
    featured: true,
    img: "pizza-bianca"
  }, {
    name: "Primavera",
    description: "Tomatoes, mozzarella and basil",
    price: 80,
    img: "pizza-primavera"
  }, {
    name: "Veloce",
    description: "Butternut, feta, onions and sunflower seeds",
    price: 100,
    img: "pizza-veloce"
  }, {
    name: "Sprint",
    description: "Salami, caramelised onions and hot honey",
    price: 120,
    img: "pizza-sprint"
  }, {
    name: "Arcobaleno",
    description: "Salami, feta, mushrooms and rocket",
    price: 140,
    img: "pizza-arcobaleno"
  }, {
    name: "Bianca Pollo",
    description: "White base, smoked chicken, mushrooms and chives",
    price: 135,
    note: "New special",
    img: "pizza-bianca-pollo"
  }, {
    name: "Sole",
    description: "White base, yellow peppers, cherry tomatoes and mint",
    price: 110,
    note: "New special",
    img: "pizza-sole"
  }, {
    name: "Rally",
    description: "BBQ glaze, smoked chicken, mushrooms and avocado",
    price: 150,
    featured: true,
    img: "pizza-rally"
  }, {
    name: "Bosco",
    description: "Tomatoes, mozzarella, mushrooms, garlic, rosemary and rocket",
    price: 125,
    note: "Concept special",
    img: "pizza-bosco"
  }, {
    name: "Bandito",
    description: "Spicy salami, red onion, roasted peppers, chilli and hot honey",
    price: 145,
    note: "Concept special",
    img: "pizza-bandito"
  }, {
    name: "Verde",
    description: "Pesto, mozzarella, courgette, artichokes, feta and rocket",
    price: 130,
    note: "Concept special",
    img: "pizza-verde"
  }, {
    name: "Tramonto",
    description: "Roasted peppers, onions, feta, cherry tomatoes and basil",
    price: 125,
    note: "Concept special",
    img: "pizza-tramonto"
  }],
  sides: [{
    name: "Caffè",
    tone: "orange",
    mark: "red-cup",
    kicker: "For before, after, or instead of sensible decisions.",
    groups: [{
      price: "R15/20",
      items: [{
        name: "Espresso",
        description: "Single · Double"
      }]
    }, {
      price: "R30",
      items: [{
        name: "Americano"
      }, {
        name: "Cappuccino"
      }, {
        name: "Flat White"
      }]
    }, {
      price: "R35",
      items: [{
        name: "Latte"
      }, {
        name: "Cortado"
      }]
    }, {
      price: "R40",
      items: [{
        name: "Mocha"
      }, {
        name: "Iced Coffee"
      }]
    }]
  }, {
    name: "Bevande",
    tone: "cream",
    kicker: "Beyond coffee. Still worth a stop.",
    groups: [{
      price: "R15",
      items: [{
        name: "Tea"
      }]
    }, {
      price: "R35",
      items: [{
        name: "Hot Chocolate"
      }, {
        name: "Chai"
      }]
    }]
  }, {
    name: "Dolci",
    tone: "pink",
    mark: "red-ice-cream",
    kicker: "Something sweet. No speech required.",
    groups: [{
      price: "R40",
      items: [{
        name: "Crema Dulce"
      }]
    }, {
      price: "R45",
      items: [{
        name: "Gelato",
        description: "Nut Biscoff · Vanilla hot honey · Berries"
      }]
    }, {
      price: "R65",
      items: [{
        name: "Limoncello"
      }]
    }]
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.js", error: String((e && e.message) || e) }); }

__ds_ns.PhotoCard = __ds_scope.PhotoCard;

__ds_ns.PopShape = __ds_scope.PopShape;

__ds_ns.RulesCard = __ds_scope.RulesCard;

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.AnnouncementBar = __ds_scope.AnnouncementBar;

__ds_ns.MobileOrderBar = __ds_scope.MobileOrderBar;

__ds_ns.SiteFooter = __ds_scope.SiteFooter;

__ds_ns.SiteHeader = __ds_scope.SiteHeader;

__ds_ns.Ticker = __ds_scope.Ticker;

__ds_ns.BrandIcon = __ds_scope.BrandIcon;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.CheckerStrip = __ds_scope.CheckerStrip;

__ds_ns.HalalBadge = __ds_scope.HalalBadge;

__ds_ns.SectionNumber = __ds_scope.SectionNumber;

__ds_ns.Stamp = __ds_scope.Stamp;

__ds_ns.Sticker = __ds_scope.Sticker;

__ds_ns.MenuCategory = __ds_scope.MenuCategory;

__ds_ns.PizzaCard = __ds_scope.PizzaCard;

})();
