const { Button, Stamp, SectionNumber, RulesCard, PizzaCard, PhotoCard, PopShape, Ticker, Sticker, HalalBadge, MenuCategory, BrandIcon, CheckerStrip } = window.PizzaRattoDesignSystem_c589b8;
const prH = { fontFamily: "var(--font-headline)", fontWeight: 700, letterSpacing: "var(--track-headline)", lineHeight: "var(--lh-headline)", margin: 0, textWrap: "balance" };
const prImg = (n) => window.prAsset("assets/photos/" + n + ".webp");
const prInk = (c = "var(--ratto-brown)") => ({ border: "3px solid var(--ratto-brown)", boxShadow: "6px 6px 0 " + c });

function Hero({ t }) {
  const b = window.PR_SITE.business;
  return <section id="top" className="pr-hero2" aria-labelledby="hero-title" style={{ "--paper": `url("${window.prAsset("assets/hero/hero-paper-texture.webp")}")` }}>
    <CheckerStrip variant="ink" size={22} />
    <div className="pr-hero2-grid">
      <div className="pr-hero2-art">
        <img src={window.prAsset("pizza-ratto-logo-mvjhg2m9-mtqq.png")} width="1698" height="926" alt="Pizza Ratto hand-painted logo beside Remi the rat riding a Vespa" fetchpriority="high" decoding="async" />
        <p className="pr-hero2-foot">Good pizza · questionable influence · zero fuss</p>
      </div>
      <div className="pr-hero2-copy">
        <SpinStamp motion={t.motion} className="pr-hero2-stamp" />
        <SectionNumber label="Wood-fired · Salt River · Cape Town" color="var(--ratto-pink)" />
        <h1 id="hero-title" style={{ ...prH, fontSize: "clamp(2.5rem, 4.7vw, 5.6rem)", color: "var(--paper-cream)" }}>Pizza with<br /><span style={{ color: "var(--ratto-pink)" }}>street‑corner</span><br />attitude.</h1>
        <p className="pr-lead">Hand-stretched, fired hot and ready for collection.</p>
        <div className="pr-row">
          <Button variant="cream" icon="whatsapp" href={b.whatsapp}>Order on WhatsApp</Button>
          <Button variant="street" icon="ubereats" href={b.uber}>Uber Eats</Button>
        </div>
        <a className="pr-phone pr-phone-cream" href={"tel:" + b.phoneIntl}><BrandIcon name="call" size={22} />{b.phone}</a>
      </div>
    </div>
    <CheckerStrip variant="pink" size={22} />
  </section>;
}

function Story({ t }) {
  return <section id="story" className="pr-sec pr-story" aria-labelledby="story-title">
    <div>
      <SectionNumber number={1} label="What we’re about" />
      <h2 id="story-title" style={{ ...prH, fontSize: "clamp(3rem, 8vw, 8.4rem)" }}>Respect fire,<br />time &amp; tomatoes.</h2>
      <p className="pr-lead" style={{ maxWidth: 600 }}>We’re not saving the world. We’re making it better one pizza at a time. Dough stretched by hand. Proper ingredients. Big Bertha running hot. No gimmicks.</p>
    </div>
    <RulesCard tone="brown" rotate={3} items={["Hand-stretched", "Wood-fired", "Proper ingredients", "Zero fuss"]} style={prInk("var(--paper-cream)")} />
  </section>;
}

function PizzaMenu({ t }) {
  const [filter, setFilter] = React.useState("All");
  const list = window.PR_SITE.pizzas.filter(p => filter === "All" || (filter === "Favourites" ? p.featured : filter === "Specials" ? !!p.note : !p.note));
  return <section id="menu" className="pr-sec pr-grain pr-cream pr-crop" aria-labelledby="pizza-title">
    <div className="pr-menu-head">
      <div><SectionNumber number={2} label="The important bit · Twelve rides. One very hot oven." color="var(--ratto-red)" />
        <h2 id="pizza-title" aria-label="Hot pizza" className="pr-mega">
          <Handwriting text="Hot" color="#421212" width={2} motion={t.motion} className="pr-hot" />
          <span aria-hidden="true">pizza</span></h2></div>
      <div className="pr-fire"><img src={window.prAsset("assets/brand/red-pizza-slice.svg")} width="64" height="71" alt="" /><span>Wood-fired<br />by Big Bertha</span></div>
    </div>
    <div className="pr-chips" role="group" aria-label="Filter pizzas">
      {["All", "Classics", "Specials", "Favourites"].map(f => <button key={f} aria-pressed={filter === f} className="pr-chip" onClick={() => setFilter(f)}>{f}</button>)}
    </div>
    <ul className="pr-pizza-grid">
      {list.map(p => <li key={p.name}><PizzaCard {...p} image={prImg(p.img)} /></li>)}
    </ul>
    <div className="pr-row" style={{ alignItems: "center", gap: "1.6rem", marginTop: "3.5rem" }}>
      <Sticker variant="hot" rotate={-4} style={{ fontSize: ".85rem", padding: ".8rem 1.2rem", ...prInk() }}>Hot honey &amp; rat sauce · R15 each</Sticker>
      <HalalBadge size={84} color="var(--ratto-brown)" background="var(--paper-cream)" label="Halal meat toppings" />
    </div>
  </section>;
}

function SideMenu({ t }) {
  return <section className="pr-sec pr-brown" aria-labelledby="sides-title">
    <SectionNumber label="Caffè · Bevande · Dolci" color="var(--hot-orange)" />
    <h2 id="sides-title" style={{ ...prH, fontSize: "clamp(2.8rem, 6.4vw, 6.6rem)", color: "var(--ratto-pink)", marginBottom: "2.8rem" }}>Coffee, drinks<br />&amp; something sweet.</h2>
    <div className="pr-side-grid">
      {window.PR_SITE.sides.map(c => <div key={c.name} className="pr-shadow-hot"><MenuCategory {...c} mark={c.mark ? <img src={window.prAsset("assets/brand/" + c.mark + ".svg")} width="44" height="52" alt="" style={{ width: 44, height: "auto" }} /> : null} /></div>)}
    </div>
  </section>;
}

function Ingredients({ t }) {
  return <section className="pr-sec pr-split pr-pink" aria-labelledby="ing-title">
    <div style={{ position: "relative" }}>
      <PhotoCard shape="arch" aspect="4 / 5" src={prImg("feast-landscape")} alt="A full Pizza Ratto table spread with pizzas, desserts, hot honey and fresh ingredients" />
      <PopShape shape="leaf" color="var(--basil-green)" size={110} rotate={-28} style={{ position: "absolute", right: "-4%", top: "-4%" }} />
    </div>
    <div>
      <SectionNumber number={3} label="Built different" color="var(--ratto-red)" />
      <h2 id="ing-title" style={{ ...prH, fontSize: "clamp(2.8rem, 6vw, 6.4rem)", color: "var(--ratto-red)" }}>Proper ingredients.<br /><span style={{ color: "var(--ratto-brown)" }}>Questionable mascot.</span></h2>
      <p className="pr-body">Our dough is stretched by hand and fired with intent. Italian mozzarella comes from Puglia. Our meat toppings are halal and sourced from Mubarak Food Emporium.</p>
      <Sticker variant="note" rotate={-3} style={{ fontFamily: "var(--font-display)", fontSize: "1.15rem", letterSpacing: 0, textTransform: "none", padding: ".8rem 1.3rem", ...prInk("var(--ratto-red)") }}>No shortcuts. No sad crusts.</Sticker>
    </div>
  </section>;
}

function Remi({ t }) {
  return <section id="remi" className="pr-remi pr-grain" aria-labelledby="remi-title">
    <div className="pr-remi-stage">
      <div className="pr-remi-copy">
        <SectionNumber label="The characters · Rat #01: Remi" color="var(--ratto-red)" />
        <h2 id="remi-title" style={{ ...prH, fontSize: "clamp(3.4rem, 8vw, 8.6rem)" }}>Meet the<br /><span style={{ color: "var(--ratto-red)" }}>Rat Pack.</span></h2>
        <p className="pr-body">Resident rat. Patron saint of good decisions made near a pizza oven. Around the room, his mural was painted by local artist Buffy.</p>
      </div>
      <figure className="pr-remi-fig">
        <div className="pr-remi-disc" aria-hidden="true"></div>
        <div className="pr-remi-media"><img src={window.prAsset("assets/mascot/ratto-vespa-cutout.webp")} width="900" height="1179" loading="lazy" decoding="async" alt="Hand-drawn Remi riding a bright red Vespa while eating pepperoni pizza" /></div>
        <figcaption className="pr-remi-cap">Approach with pizza. He startles easily.</figcaption>
      </figure>
    </div>
  </section>;
}

const PR_HOUSE_SLIDES = [
  { img: "video-stills/oven-flames", alt: "Flames inside Pizza Ratto's wood-fired oven, Big Bertha", label: "Fire #01 · Heart of the house", title: "Big Bertha.", body: "The wood-fired heart of the operation. Every pizza meets the flame here." },
  { img: "video-stills/pizza-pass", alt: "A fresh pizza coming out of the oven onto the pass", label: "Fire #02 · Oven to pass", title: "Straight out.", body: "Fired, cut and boxed while it still has something to say." },
  { img: "video-stills/espresso-pull", alt: "Espresso pulling into a cup at the Pizza Ratto counter", label: "Fire #03 · Caffè", title: "Then coffee.", body: "For before, after, or instead of sensible decisions." }
];

function HouseSlider() {
  const [i, setI] = React.useState(0), n = PR_HOUSE_SLIDES.length;
  const go = (d) => setI((i + d + n) % n);
  return <article className="pr-panel pr-panel-brown pr-bertha-slider" aria-roledescription="carousel" aria-label="Inside the house">
    <div className="pr-slides">
      {PR_HOUSE_SLIDES.map((sl, k) => <div key={sl.img} className={"pr-bertha pr-slide" + (k === i ? " is-on" : "")} aria-hidden={k !== i} role="group" aria-roledescription="slide" aria-label={(k + 1) + " of " + n}>
        <div className="pr-oven"><img src={prImg(sl.img)} width="900" height="900" loading="lazy" decoding="async" alt={sl.alt} /></div>
        <div><SectionNumber label={sl.label} color="var(--hot-orange)" />
          <h3 style={{ ...prH, fontFamily: "var(--font-display)", fontWeight: 400, letterSpacing: 0, fontSize: "clamp(3rem, 6vw, 5.6rem)", color: "var(--ratto-pink)" }}>{sl.title}</h3>
          <p className="pr-body" style={{ color: "var(--paper-cream)" }}>{sl.body}</p></div>
      </div>)}
    </div>
    <div className="pr-slide-nav">
      <button type="button" className="pr-slide-btn" onClick={() => go(-1)} aria-label="Previous slide">←</button>
      <div className="pr-dots">{PR_HOUSE_SLIDES.map((sl, k) => <button key={k} type="button" className="pr-dot" aria-pressed={k === i} aria-label={"Go to slide " + (k + 1)} onClick={() => setI(k)}></button>)}</div>
      <button type="button" className="pr-slide-btn" onClick={() => go(1)} aria-label="Next slide">→</button>
    </div>
  </article>;
}

function ContactForm() {
  const b = window.PR_SITE.business;
  const submit = (e) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const msg = "Hi Pizza Ratto, it's " + f.get("name") + (f.get("phone") ? " (" + f.get("phone") + ")" : "") + ". " + f.get("message");
    window.open("https://wa.me/" + b.phoneIntl.replace(/\D/g, "") + "?text=" + encodeURIComponent(msg), "_blank", "noopener");
  };
  return <article className="pr-panel pr-panel-cream">
    <form className="pr-form" onSubmit={submit}>
      <div><SectionNumber label="Get in touch" color="var(--ratto-red)" />
        <h3 style={{ ...prH, fontSize: "clamp(2.2rem, 3.6vw, 3.4rem)", color: "var(--ratto-brown)" }}>Say ciao.</h3></div>
      <label className="pr-field"><span>Name</span><input name="name" required autoComplete="name" /></label>
      <label className="pr-field"><span>Phone</span><input name="phone" type="tel" autoComplete="tel" inputMode="tel" /></label>
      <label className="pr-field"><span>Message</span><textarea name="message" rows="4" required></textarea></label>
      <Button type="submit" variant="street" icon="whatsapp" style={prInk()}>Send on WhatsApp</Button>
    </form>
  </article>;
}

function House({ t }) {
  return <section className="pr-sec pr-orange" aria-labelledby="house-title">
    <SectionNumber number={4} label="The house" />
    <h2 id="house-title" className="pr-sr">Big Bertha and getting in touch</h2>
    <div className="pr-house">
      <HouseSlider />
      <ContactForm />
    </div>
  </section>;
}

function Social({ t }) {
  const b = window.PR_SITE.business;
  return <section className="pr-sec pr-brown pr-crop" aria-labelledby="social-title">
    <div className="pr-social-head">
      <div><SectionNumber number={5} label="Ratto Social Club" color="var(--hot-orange)" />
        <h2 id="social-title" style={{ ...prH, fontSize: "clamp(3.2rem, 8vw, 8.6rem)", color: "var(--paper-cream)" }}>Never pizza <span style={{ color: "var(--hot-orange)" }}>solo.</span></h2></div>
      <div><p className="pr-body" style={{ color: "var(--paper-cream)", marginTop: 0 }}>Follow the daily damage, fresh pies and questionable decisions.</p>
        <Button variant="hot" icon="instagram" href={b.instagram} style={{ border: "3px solid var(--paper-cream)", boxShadow: "6px 6px 0 var(--ratto-red)" }}>Follow {b.handle}</Button></div>
    </div>
    <div className="pr-tapes-head pr-tapes-first">
      <h3 style={{ ...prH, fontSize: "clamp(2.6rem, 5.6vw, 5.4rem)", color: "var(--paper-cream)" }}>Fresh proof.<br /><span style={{ fontFamily: "var(--font-display)", fontWeight: 400, letterSpacing: 0, color: "var(--ratto-pink)" }}>No filters.</span></h3>
      <div><span className="pr-label" style={{ color: "var(--hot-orange)" }}>From the counter / 07 shorts</span><p className="pr-body" style={{ color: "var(--paper-cream)", margin: ".8rem 0 0", maxWidth: 360 }}>A few seconds from Big Bertha, the pass and the counter. Swipe sideways for the full roll.</p></div>
    </div>
    <div className="pr-reel" role="region" aria-label="Short owner videos from Pizza Ratto" tabIndex={0}>
      {window.PR_SITE.tapes.map((v, i) => <TapeVideo key={v.vid} tape={v} n={i + 1} motion={t.motion} />)}
    </div>
  </section>;
}

function Visit({ t }) {
  const b = window.PR_SITE.business;
  const row = (k, v) => <div className="pr-dl-row"><dt>{k}</dt><dd>{v}</dd></div>;
  return <section id="visit" className="pr-sec pr-visit pr-red pr-crop" aria-labelledby="visit-title">
    <div className="pr-visit-title">
      <SectionNumber number={6} label="Find the fire" color="var(--ratto-pink)" />
      <h2 id="visit-title" style={{ ...prH, fontSize: "clamp(2.4rem, 9.4vw, 10rem)", color: "var(--paper-cream)" }}>Salt River.<br /><span style={{ color: "var(--ratto-pink)" }}>Come say ciao.</span></h2>
    </div>
    <div>
      <p className="pr-lead" style={{ color: "var(--paper-cream)", marginTop: 0 }}>Fresh from the oven. Straight to your face — collect, or order on Uber Eats.</p>
      <dl className="pr-dl">{row("Where", <address>{b.location}</address>)}{row("When", b.hours)}{row("Call / WhatsApp", <a href={"tel:" + b.phoneIntl} style={{ fontFamily: "var(--font-display)", fontSize: "1.6rem" }}>{b.phone}</a>)}</dl>
      <div className="pr-row" style={{ marginTop: "1.6rem" }}>
        <Button variant="cream" icon="whatsapp" href={b.whatsapp} style={prInk()}>WhatsApp an order ↗</Button>
        <Button variant="hot" icon="ubereats" href={b.uber} style={prInk()}>Order on Uber Eats ↗</Button>
      </div>
    </div>
    <div style={{ position: "relative" }}>
      <PhotoCard shape="arch" aspect="4 / 5" src={prImg("interior")} alt="Pizza Ratto dining room with brick walls, vintage furniture and a Vespa" background="var(--ratto-pink)" />
      <PopShape shape="wheel" color="var(--paper-cream)" size={120} style={{ position: "absolute", left: "-8%", bottom: "6%" }} />
    </div>
  </section>;
}

Object.assign(window, { Hero, Story, PizzaMenu, SideMenu, Ingredients, Remi, House, Social, Visit, Ticker });
